@echo off
chcp 65001 >nul
cd /d "%~dp0"
cscript //nologo "%~dp0install-startup.vbs"
if errorlevel 1 (
    echo 자동 시작 등록에 실패했습니다.
    pause
    exit /b 1
)
echo.
echo Windows에 로그인하면 TBM 서버가 자동으로 켜집니다.
echo 다른 컴퓨터로 폴더를 옮긴 뒤에는 이 파일을 한 번 더 실행하세요.
echo.
cscript //nologo "%~dp0start-hidden.vbs"
ping 127.0.0.1 -n 3 >nul
start "" "http://localhost:3000"
pause
