/**
 * 작업계획서 우측 하단에 TBM QR을 넣습니다.
 */

const ExcelJS = require('exceljs');
const QRCode = require('qrcode');
const XLSX = require('xlsx');
const path = require('path');

/**
 * 브리핑 주소로 QR PNG를 만듭니다.
 * @param {string} url - 반장용 모바일 주소
 * @returns {Promise<Buffer>} PNG 버퍼
 */
async function buildQrPng(url) {
    return QRCode.toBuffer(url, {
        type: 'png',
        width: 320,
        margin: 1,
        errorCorrectionLevel: 'M',
    });
}

/**
 * xls 파일을 xlsx 버퍼로 바꿉니다.
 * @param {Buffer} buffer - 원본 파일
 * @returns {Buffer} xlsx 버퍼
 */
function toXlsxBuffer(buffer) {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}

/**
 * 첫 시트 우측 하단에 QR 이미지를 삽입한 작업계획서를 만듭니다.
 * @param {Buffer} originalBuffer - 원본 엑셀
 * @param {Buffer} qrBuffer - QR PNG
 * @param {string} fileName - 원본 파일명
 * @returns {Promise<Buffer>} QR이 들어간 xlsx
 */
function colToLetter(col) {
    let letter = '';
    let temp = col;
    while (temp > 0) {
        let rem = (temp - 1) % 26;
        letter = String.fromCharCode(65 + rem) + letter;
        temp = Math.floor((temp - 1) / 26);
    }
    return letter;
}

function letterToCol(letters) {
    let col = 0;
    const str = String(letters || '').toUpperCase();
    for (let i = 0; i < str.length; i++) {
        col = col * 26 + (str.charCodeAt(i) - 64);
    }
    return col;
}

/**
 * 첫 시트 우측 맨 하단에 인쇄 시 잘리지 않도록 QR 이미지를 삽입한 작업계획서를 만듭니다.
 * @param {Buffer} originalBuffer - 원본 엑셀
 * @param {Buffer} qrBuffer - QR PNG
 * @param {string} fileName - 원본 파일명
 * @returns {Promise<Buffer>} QR이 들어간 xlsx
 */
async function stampQrOnWorkplan(originalBuffer, qrBuffer, fileName) {
    const workbook = new ExcelJS.Workbook();
    const ext = path.extname(fileName || '').toLowerCase();
    const source = ext === '.xls' ? toXlsxBuffer(originalBuffer) : originalBuffer;
    await workbook.xlsx.load(source);

    const sheet = workbook.worksheets[0];
    if (!sheet) return workbook.xlsx.writeBuffer();

    // 1. 실제 데이터(값/텍스트)가 있는 최대 행 및 열 탐색
    let maxValRow = 0;
    let maxValCol = 0;
    sheet.eachRow({ includeEmpty: false }, (row, r) => {
        row.eachCell({ includeEmpty: false }, (cell, c) => {
            const hasVal = cell.value !== null && cell.value !== undefined && cell.value !== '';
            if (hasVal) {
                maxValRow = Math.max(maxValRow, r);
                maxValCol = Math.max(maxValCol, c);
            }
        });
    });

    // 2. 인쇄 영역(printArea) 기준 열/행 계산
    let printCol = maxValCol || 40;
    let printRow = maxValRow || 86;
    if (sheet.pageSetup && sheet.pageSetup.printArea) {
        const parts = sheet.pageSetup.printArea.split(':');
        if (parts.length === 2) {
            const match = parts[1].match(/([A-Z]+)(\d+)/i);
            if (match) {
                const parsedCol = letterToCol(match[1]);
                const parsedRow = parseInt(match[2], 10);
                if (parsedCol > 0) printCol = Math.max(printCol, parsedCol);
                if (parsedRow > 0) printRow = Math.max(printRow, parsedRow);
            }
        }
    }

    // 3. 표 내부 우측 하단이 비어있는지 확인 (하위 6행, 우측 10열)
    const checkStartRow = Math.max(1, printRow - 5);
    const checkStartCol = Math.max(1, printCol - 10);
    let cornerEmpty = true;
    for (let r = checkStartRow; r <= printRow; r++) {
        const row = sheet.getRow(r);
        for (let c = checkStartCol; c <= printCol; c++) {
            const val = row.getCell(c).value;
            if (val !== null && val !== undefined && val !== '') {
                cornerEmpty = false;
                break;
            }
        }
        if (!cornerEmpty) break;
    }

    let tlCol, tlRow, finalPrintRow;
    if (cornerEmpty) {
        // 표 내부 우측 하단 빈 공간에 배치 (0-indexed)
        tlCol = Math.max(0, printCol - 8);
        tlRow = Math.max(0, printRow - 6);
        finalPrintRow = printRow;
    } else {
        // 표 바로 아래 행에 우측 정렬로 배치
        tlCol = Math.max(0, printCol - 8);
        tlRow = printRow;
        finalPrintRow = printRow + 7;
    }

    // 4. QR 이미지 삽입 (110x110 픽셀)
    const imageId = workbook.addImage({ buffer: qrBuffer, extension: 'png' });
    sheet.addImage(imageId, {
        tl: { col: tlCol, row: tlRow },
        ext: { width: 110, height: 110 },
        editAs: 'oneCell',
    });

    // 5. 라벨 텍스트 삽입 (QR 왼쪽 또는 위쪽에 표시)
    try {
        const labelRow = tlRow + 1;
        const labelCol = Math.max(1, tlCol - 3);
        const labelCell = sheet.getCell(labelRow, labelCol);
        if (!labelCell.value) {
            labelCell.value = 'TBM 브리핑 QR:';
            labelCell.font = { name: '맑은 고딕', size: 9, bold: true, color: { argb: 'FF374151' } };
        }
    } catch {
        // 라벨 삽입 실패 시 이미지 배치만 유지
    }

    // 6. 인쇄 설정(PageSetup) 보정: QR 코드가 인쇄물 맨 우측 맨 하단에 100% 나오도록 보장
    if (!sheet.pageSetup) sheet.pageSetup = {};
    sheet.pageSetup.printArea = `A1:${colToLetter(printCol)}${finalPrintRow}`;
    sheet.pageSetup.fitToPage = true;
    sheet.pageSetup.fitToWidth = 1;
    if (sheet.pageSetup.fitToHeight === undefined) {
        sheet.pageSetup.fitToHeight = 0;
    }

    return workbook.xlsx.writeBuffer();
}

module.exports = { buildQrPng, stampQrOnWorkplan };
