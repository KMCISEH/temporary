/**
 * Microsoft Edge 온라인 TTS로 한국어 남성(InJoon) mp3를 만듭니다.
 * API 키가 없고, 막히면 호출 쪽에서 기기 TTS로 넘어가면 됩니다.
 */

const os = require('os');
const path = require('path');
const fsp = require('fs').promises;
const { EdgeTTS } = require('node-edge-tts');

const VOICE = 'ko-KR-InJoonNeural';

/**
 * 낭독용으로 줄바꿈을 공백으로 바꿉니다.
 * @param {string} text - TBM 대본
 * @returns {string} 한 줄 텍스트
 */
function spokenText(text) {
    return String(text || '')
        .replace(/\r\n/g, '\n')
        .replace(/\n+/g, ' ')
        .replace(/[ \t]+/g, ' ')
        .trim();
}

/**
 * InJoon 목소리 mp3 버퍼를 만듭니다.
 * @param {string} text - TBM 대본
 * @returns {Promise<Buffer>} mp3 데이터
 */
async function synthesizeInJoonMp3(text) {
    const startedAt = Date.now();
    const spoken = spokenText(text);
    if (!spoken) {
        throw new Error('읽을 대본이 없습니다.');
    }

    const tmpPath = path.join(os.tmpdir(), `tbm-tts-${Date.now()}-${process.pid}.mp3`);
    const tts = new EdgeTTS({
        voice: VOICE,
        lang: 'ko-KR',
        outputFormat: 'audio-24khz-48kbitrate-mono-mp3',
        pitch: '-8%',
        rate: '+8%',
        timeout: 45000,
    });

    try {
        await tts.ttsPromise(spoken, tmpPath);
        const buffer = await fsp.readFile(tmpPath);
        if (!buffer.length) {
            throw new Error('음성 파일이 비어 있습니다.');
        }
        console.log(`[Edge TTS] 인준 음성 생성, ${buffer.length}bytes, 소요=${Date.now() - startedAt}ms`);
        return buffer;
    } finally {
        await fsp.unlink(tmpPath).catch(() => {});
    }
}

module.exports = { synthesizeInJoonMp3, VOICE };
