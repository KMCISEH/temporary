/**
 * 기상청 API 호출 모듈
 * 
 * 3종 API를 호출하여 TBM에 필요한 날씨 정보를 수집합니다:
 * 1. 초단기실황 (getUltraSrtNcst) — 현재 기온, 습도, 풍속
 * 2. 단기예보 (getVilageFcst) — 최저/최고기온, 하늘상태, 강수확률
 * 3. 특보현황 (getWthrWrnSts) — 폭염/한파/호우 등 기상 특보
 */

const KMA_BASE_URL = 'http://apis.data.go.kr/1360000';

// ── 하늘상태/강수형태 코드 → 텍스트 변환 ──
const SKY_CODE = { '1': '맑음', '3': '구름많음', '4': '흐림' };
const PTY_CODE = { '0': '없음', '1': '비', '2': '비/눈', '3': '눈', '4': '소나기', '5': '빗방울', '6': '빗방울눈날림', '7': '눈날림' };

/**
 * 날짜/시간 유틸리티
 */
function getFormattedDate(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}${m}${d}`;
}

function getFormattedTime(date) {
    const h = String(date.getHours()).padStart(2, '0');
    const m = String(date.getMinutes()).padStart(2, '0');
    return `${h}${m}`;
}

/**
 * 초단기실황에 맞는 base_time 계산
 * 매시 정각 발표, API 제공은 40분 이후 → 현재시각 - 1시간의 정각
 */
function getUltraSrtNcstBaseTime(now) {
    const minutes = now.getMinutes();
    let baseHour = now.getHours();
    
    // 40분 이전이면 이전 시간 데이터 사용
    if (minutes < 40) {
        baseHour -= 1;
    }
    
    if (baseHour < 0) {
        baseHour = 23;
        now.setDate(now.getDate() - 1);
    }
    
    return {
        baseDate: getFormattedDate(now),
        baseTime: String(baseHour).padStart(2, '0') + '00'
    };
}

/**
 * 단기예보에 맞는 base_time 계산
 * 발표시각: 02, 05, 08, 11, 14, 17, 20, 23시
 * TBM은 보통 오전 7~8시 → 05시 발표 데이터가 최적
 */
function getVilageFcstBaseTime(now) {
    const baseTimes = [2, 5, 8, 11, 14, 17, 20, 23];
    const currentHour = now.getHours();
    const currentMin = now.getMinutes();

    // 발표 후 약 10분 뒤 API 제공
    let selectedBase = baseTimes[0];
    let baseDate = new Date(now);

    for (let i = baseTimes.length - 1; i >= 0; i--) {
        const bh = baseTimes[i];
        if (currentHour > bh || (currentHour === bh && currentMin >= 10)) {
            selectedBase = bh;
            break;
        }
        if (i === 0) {
            // 02시 10분 이전 → 전날 23시 데이터
            selectedBase = 23;
            baseDate.setDate(baseDate.getDate() - 1);
        }
    }

    return {
        baseDate: getFormattedDate(baseDate),
        baseTime: String(selectedBase).padStart(2, '0') + '00'
    };
}

/**
 * 1) 초단기실황 조회
 */
async function fetchCurrentWeather(apiKey, nx, ny) {
    const now = new Date();
    const { baseDate, baseTime } = getUltraSrtNcstBaseTime(new Date(now));

    const params = new URLSearchParams({
        serviceKey: apiKey,
        pageNo: '1',
        numOfRows: '10',
        dataType: 'JSON',
        base_date: baseDate,
        base_time: baseTime,
        nx: String(nx),
        ny: String(ny),
    });

    const url = `${KMA_BASE_URL}/VilageFcstInfoService_2.0/getUltraSrtNcst?${params}`;
    
    try {
        const res = await fetch(url);
        const json = await res.json();

        if (json.response?.header?.resultCode !== '00') {
            console.error('[초단기실황] API 오류:', json.response?.header?.resultMsg);
            return null;
        }

        const items = json.response.body.items.item;
        const data = {};
        items.forEach(item => {
            data[item.category] = item.obsrValue;
        });

        return {
            temperature: data.T1H ? `${data.T1H}℃` : null,     // 기온
            humidity: data.REH ? `${data.REH}%` : null,          // 습도
            rainfall: data.RN1 ? `${data.RN1}mm` : null,        // 1시간 강수량
            windSpeed: data.WSD ? `${data.WSD}m/s` : null,      // 풍속
            precipType: data.PTY ? PTY_CODE[data.PTY] || data.PTY : '없음', // 강수형태
        };
    } catch (err) {
        console.error('[초단기실황] 호출 실패:', err.message);
        return null;
    }
}

/**
 * 2) 단기예보 조회 (최저/최고기온, 하늘상태, 강수확률)
 */
async function fetchForecast(apiKey, nx, ny) {
    const now = new Date();
    const { baseDate, baseTime } = getVilageFcstBaseTime(new Date(now));
    const todayStr = getFormattedDate(now);

    const params = new URLSearchParams({
        serviceKey: apiKey,
        pageNo: '1',
        numOfRows: '300',
        dataType: 'JSON',
        base_date: baseDate,
        base_time: baseTime,
        nx: String(nx),
        ny: String(ny),
    });

    const url = `${KMA_BASE_URL}/VilageFcstInfoService_2.0/getVilageFcst?${params}`;

    try {
        const res = await fetch(url);
        const json = await res.json();

        if (json.response?.header?.resultCode !== '00') {
            console.error('[단기예보] API 오류:', json.response?.header?.resultMsg);
            return null;
        }

        const items = json.response.body.items.item;
        
        // 오늘 날짜 데이터만 필터
        const todayItems = items.filter(item => item.fcstDate === todayStr);

        let tmn = null, tmx = null, sky = null, pop = null;

        todayItems.forEach(item => {
            if (item.category === 'TMN') tmn = item.fcstValue;
            if (item.category === 'TMX') tmx = item.fcstValue;
            // 가장 가까운 시간대의 하늘상태와 강수확률
            if (item.category === 'SKY' && !sky) sky = item.fcstValue;
            if (item.category === 'POP' && !pop) pop = item.fcstValue;
        });

        return {
            minTemp: tmn ? `${tmn}℃` : null,
            maxTemp: tmx ? `${tmx}℃` : null,
            sky: sky ? (SKY_CODE[sky] || sky) : null,
            rainProb: pop ? `${pop}%` : null,
        };
    } catch (err) {
        console.error('[단기예보] 호출 실패:', err.message);
        return null;
    }
}

// 여수(KMCI 현장) 기상청 지점코드
const YEOSU_STN_ID = '168';

/**
 * 특보 발표시각을 숫자로 바꿉니다.
 * @param {object} item - 특보 항목
 * @returns {number} YYYYMMDDHHmm
 */
function warningTimeValue(item) {
    const raw = String(item.tmFc || item.content || '').replace(/\D/g, '');
    return Number(raw.slice(0, 12) || '0');
}

/**
 * 특보 제목에서 가장 앞의 한 줄만 남깁니다.
 * @param {string} title - 원문 제목
 * @returns {string} 짧은 특보 문구
 */
function shortenWarningTitle(title) {
    const text = String(title || '').replace(/\s+/g, ' ').trim();
    if (!text) return '';
    const numbered = text.split(/\(\d+\)/).map((part) => part.trim()).filter(Boolean);
    const chosen = numbered.length > 1 ? numbered[0] : text;
    return chosen.replace(/^\[특보\]\s*/, '').replace(/^[,:.\-\s]+/, '').slice(0, 80);
}

/**
 * 목록에서 전남·여수 관련(없으면 전체) 최신 특보 1건을 고릅니다.
 * @param {object[]} warningList - 특보 목록
 * @returns {{title: string, content: string}|null} 최신 특보
 */
function pickLatestWarning(warningList) {
    if (!Array.isArray(warningList) || warningList.length === 0) return null;
    const local = warningList.filter((item) => /전남|여수|순천|광양/.test(item.title || ''));
    const pool = (local.length ? local : warningList).slice();
    pool.sort((a, b) => warningTimeValue(b) - warningTimeValue(a));
    const latest = pool[0];
    const title = shortenWarningTitle(latest.title);
    if (!title) return null;
    return { title, content: String(latest.tmFc || '') };
}

/**
 * 기상특보 목록 API를 호출합니다.
 * @param {string} apiKey - 공공데이터포털 키
 * @param {object} extraParams - stnId, fromTmFc 등
 * @returns {Promise<object[]>} 특보 원본 목록
 */
async function fetchWarningList(apiKey, extraParams) {
    const params = new URLSearchParams({
        serviceKey: apiKey,
        pageNo: '1',
        numOfRows: '20',
        dataType: 'JSON',
        ...extraParams,
    });

    const url = `${KMA_BASE_URL}/WthrWrnInfoService/getWthrWrnList?${params}`;
    const res = await fetch(url);
    const text = await res.text();

    let json;
    try {
        json = JSON.parse(text);
    } catch {
        console.warn('[특보현황] JSON 파싱 실패, XML 응답일 수 있음');
        return [];
    }

    if (json.response?.header?.resultCode !== '00') {
        return [];
    }

    const items = json.response?.body?.items?.item;
    if (!items) return [];
    return Array.isArray(items) ? items : [items];
}

/**
 * 3) 기상특보 현황 조회 — 오늘 발표분 중 최신 1건만 사용합니다.
 * @param {string} apiKey - 공공데이터포털 키
 * @returns {Promise<{warnings: object[]}>} 최신 특보
 */
async function fetchWeatherWarning(apiKey) {
    const today = getFormattedDate(new Date());

    try {
        let warningList = await fetchWarningList(apiKey, {
            stnId: YEOSU_STN_ID,
            fromTmFc: today,
            toTmFc: today,
        });
        if (warningList.length === 0) {
            warningList = await fetchWarningList(apiKey, {
                fromTmFc: today,
                toTmFc: today,
            });
        }

        const latest = pickLatestWarning(warningList);
        return { warnings: latest ? [latest] : [] };
    } catch (err) {
        console.error('[특보현황] 호출 실패:', err.message);
        return { warnings: [] };
    }
}

/**
 * 종합 날씨 요약 생성
 * 3종 API 결과를 합쳐서 TBM에 사용할 한 줄 요약 + 상세 데이터 반환
 */
async function buildWeatherSummary(apiKey, nx, ny) {
    // 3종 API 병렬 호출
    const [current, forecast, warning] = await Promise.all([
        fetchCurrentWeather(apiKey, nx, ny),
        fetchForecast(apiKey, nx, ny),
        fetchWeatherWarning(apiKey),
    ]);

    // ── 한 줄 요약 문장 조합 ──
    const parts = [];

    // 하늘상태
    if (forecast?.sky) parts.push(forecast.sky);

    // 최저/최고기온
    if (forecast?.minTemp && forecast?.maxTemp) {
        parts.push(`최저 ${forecast.minTemp} / 최고 ${forecast.maxTemp}`);
    } else if (forecast?.maxTemp) {
        parts.push(`낮 최고 ${forecast.maxTemp}`);
    }

    // 강수확률
    if (forecast?.rainProb && parseInt(forecast.rainProb) > 0) {
        parts.push(`강수확률 ${forecast.rainProb}`);
    }

    // 현재 강수
    if (current?.precipType && current.precipType !== '없음') {
        parts.push(`현재 ${current.precipType}`);
    }

    // 풍속 (강풍 시 강조)
    if (current?.windSpeed) {
        const ws = parseFloat(current.windSpeed);
        if (ws >= 10) parts.push(`강풍 ${current.windSpeed}`);
        else if (ws >= 7) parts.push(`풍속 ${current.windSpeed}`);
    }

    // 특보 — 최신 1건만 요약에 붙입니다.
    const latestWarning = warning?.warnings?.[0]?.title || '';
    if (latestWarning) {
        parts.push(`[특보] ${latestWarning}`);
    }

    const summary = parts.join(', ') || '날씨 정보를 불러올 수 없습니다';

    return {
        summary,
        current,
        forecast,
        warnings: latestWarning ? [latestWarning] : [],
        timestamp: new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }),
    };
}

module.exports = { buildWeatherSummary };
