/**
 * 같은 Wi-Fi의 휴대폰이 접속할 수 있는 LAN IP를 찾습니다.
 */

const os = require('os');

/**
 * 내부가 아닌 IPv4 주소를 반환합니다.
 * @returns {{name: string, address: string}[]} 네트워크 인터페이스 목록
 */
function getLanAddresses() {
    const nets = os.networkInterfaces();
    const results = [];

    Object.keys(nets).forEach((name) => {
        (nets[name] || []).forEach((net) => {
            const family = net.family === 'IPv4' || net.family === 4;
            if (family && !net.internal) {
                results.push({ name, address: net.address });
            }
        });
    });

    return results;
}

module.exports = { getLanAddresses };
