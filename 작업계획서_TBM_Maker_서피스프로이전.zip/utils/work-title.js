/**
 * 작업계획서에서 당일 작업제목을 찾습니다.
 */

const TITLE_KEYS = /^(?:[\d\.\s\-\*]*)(?:작업명|공사명|공종명|공종|작업\s*내용|작업\s*제목|제목)/;
const DATE_KEYS = /^(?:[\d\.\s\-\*]*)(?:작업\s*일시|작업\s*일자|작업\s*기간|공사\s*기간|일\s*시|일\s*자|기\s*간)/;

/**
 * 시트 또는 행 목록에서 작업제목을 추출합니다.
 * @param {object[]|Array[]} sheetsOrRows - 파싱된 시트 목록 또는 2차원 행 배열
 * @param {string} fileName - 원본 파일명
 * @returns {string} 작업제목
 */
function extractWorkTitle(sheetsOrRows, fileName) {
    const rows = [];
    if (Array.isArray(sheetsOrRows)) {
        sheetsOrRows.forEach((item) => {
            if (Array.isArray(item)) {
                rows.push(item);
            } else if (item && Array.isArray(item.preview)) {
                item.preview.forEach((r) => rows.push(r));
            } else if (item && Array.isArray(item.rows)) {
                item.rows.forEach((r) => rows.push(r));
            }
        });
    }

    for (let i = 0; i < rows.length; i++) {
        const row = rows[i] || [];
        for (let j = 0; j < row.length; j++) {
            const cell = String(row[j] || '').trim();
            if (!cell || !TITLE_KEYS.test(cell) || DATE_KEYS.test(cell)) continue;

            // 같은 행의 오른쪽 셀들 탐색 (병합 셀 고려)
            for (let k = j + 1; k < row.length; k++) {
                const sameRow = String(row[k] || '').trim();
                if (sameRow && !TITLE_KEYS.test(sameRow) && !DATE_KEYS.test(sameRow)) {
                    return clipTitle(sameRow);
                }
            }

            // 다음 행의 셀 탐색
            if (rows[i + 1]) {
                const nextRow = String((rows[i + 1] || [])[j] || '').trim();
                if (nextRow && !TITLE_KEYS.test(nextRow) && !DATE_KEYS.test(nextRow)) {
                    return clipTitle(nextRow);
                }
            }
        }
    }

    const fallback = String(fileName || '').replace(/\.(xlsx|xls)$/i, '').trim();
    return clipTitle(fallback || '오늘의 작업');
}

/**
 * 제목을 화면·QR용으로 짧게 자릅니다.
 * @param {string} title - 원문
 * @returns {string} 짧은 제목
 */
function clipTitle(title) {
    const text = String(title || '').replace(/\s+/g, ' ').trim();
    if (!text) return '오늘의 작업';
    return text.length > 40 ? `${text.slice(0, 40)}…` : text;
}

module.exports = { extractWorkTitle, clipTitle };
