/**
 * TBM 세션 로컬 저장소
 * 이 컴퓨터의 tbm-store/ 폴더에 작업계획서·대본·서명을 파일로 보관합니다.
 */

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const crypto = require('crypto');

const { buildQrPng, stampQrOnWorkplan } = require('./workplan-qr');

const STORE_ROOT = path.join(__dirname, '..', 'tbm-store');
const SESSIONS_DIR = path.join(STORE_ROOT, 'sessions');
const INDEX_PATH = path.join(STORE_ROOT, 'index.json');

/**
 * 저장 폴더가 없으면 생성합니다.
 * @returns {Promise<void>}
 */
async function ensureStorage() {
    await fsp.mkdir(SESSIONS_DIR, { recursive: true });
    if (!fs.existsSync(INDEX_PATH)) {
        await fsp.writeFile(INDEX_PATH, '[]', 'utf8');
    }
}

/**
 * 목록용 요약 객체를 만듭니다.
 * @param {object} record - 세션 원본
 * @returns {object} 목록 항목
 */
/**
 * 목록용 요약 객체를 만듭니다.
 * @param {object} record - 세션 원본
 * @returns {object} 목록 항목
 */
function toSummary(record) {
    const signatures = record.signatures || [];
    const signerName = signatures.find((item) => String(item.name || '').trim());
    return {
        id: record.id,
        folderName: record.folderName || record.id,
        status: record.status,
        createdAt: record.createdAt,
        completedAt: record.completedAt,
        fileName: record.fileName,
        workTitle: record.workTitle || '',
        workDate: record.workDate || '',
        chemicalHazard: record.chemicalHazard || '',
        chemicalProcess: record.chemicalProcess || '',
        weather: record.weather,
        signerCount: signatures.length,
        signerName: signerName ? signerName.name : '',
    };
}

/**
 * 인덱스 파일을 읽고 해당 세션 요약을 갱신합니다.
 * @param {object} summary - 목록 항목
 * @returns {Promise<void>}
 */
async function upsertIndex(summary) {
    await ensureStorage();
    let list = [];
    try {
        list = JSON.parse(await fsp.readFile(INDEX_PATH, 'utf8'));
        if (!Array.isArray(list)) list = [];
    } catch (err) {
        console.warn('[저장소] 인덱스 손상, 새로 작성합니다:', err.message);
        list = [];
    }

    const idx = list.findIndex((item) => item.id === summary.id);
    if (idx >= 0) list[idx] = summary;
    else list.unshift(summary);

    await fsp.writeFile(INDEX_PATH, JSON.stringify(list, null, 2), 'utf8');
}

// 세션 ID → 실제 폴더명 메모리 캐시
const sessionFolderCache = new Map();

/**
 * 세션 ID에 해당하는 실제 폴더 경로를 찾아 반환합니다.
 * (한글 작업명 폴더 및 기존 UUID 폴더 모두 지원)
 * @param {string} id - 세션 ID
 * @returns {string} 절대 경로
 */
function sessionDir(id) {
    if (!id) return path.join(SESSIONS_DIR, 'unknown');

    // 1. 메모리 캐시 확인
    if (sessionFolderCache.has(id)) {
        const cached = path.join(SESSIONS_DIR, sessionFolderCache.get(id));
        if (fs.existsSync(cached)) return cached;
    }

    // 2. 정확한 폴더명이 id인 경우 (기존 UUID 폴더)
    const exact = path.join(SESSIONS_DIR, id);
    if (fs.existsSync(exact)) {
        sessionFolderCache.set(id, id);
        return exact;
    }

    // 3. index.json에서 folderName 매핑 검색
    if (fs.existsSync(INDEX_PATH)) {
        try {
            const list = JSON.parse(fs.readFileSync(INDEX_PATH, 'utf8'));
            if (Array.isArray(list)) {
                const item = list.find((s) => s.id === id);
                if (item && item.folderName) {
                    const target = path.join(SESSIONS_DIR, item.folderName);
                    if (fs.existsSync(target)) {
                        sessionFolderCache.set(id, item.folderName);
                        return target;
                    }
                }
            }
        } catch (_) {}
    }

    // 4. sessions 폴더 내 하위 폴더의 meta.json을 스캔하여 일치하는 id 검색
    if (fs.existsSync(SESSIONS_DIR)) {
        try {
            const entries = fs.readdirSync(SESSIONS_DIR, { withFileTypes: true });
            for (const entry of entries) {
                if (entry.isDirectory()) {
                    const metaFile = path.join(SESSIONS_DIR, entry.name, 'meta.json');
                    if (fs.existsSync(metaFile)) {
                        try {
                            const meta = JSON.parse(fs.readFileSync(metaFile, 'utf8'));
                            if (meta.id === id) {
                                sessionFolderCache.set(id, entry.name);
                                return path.join(SESSIONS_DIR, entry.name);
                            }
                        } catch (_) {}
                    }
                }
            }
        } catch (_) {}
    }

    return exact;
}

/**
 * 세션 메타를 저장합니다.
 * @param {object} record - 세션 원본
 * @returns {Promise<void>}
 */
async function writeMeta(record) {
    const filePath = path.join(sessionDir(record.id), 'meta.json');
    await fsp.writeFile(filePath, JSON.stringify(record, null, 2), 'utf8');
}

/**
 * 세션을 읽어 반환합니다.
 * @param {string} id - 세션 ID
 * @returns {Promise<object|null>} 세션 또는 null
 */
async function readSession(id) {
    const filePath = path.join(sessionDir(id), 'meta.json');
    try {
        const raw = await fsp.readFile(filePath, 'utf8');
        return JSON.parse(raw);
    } catch (err) {
        if (err.code === 'ENOENT') return null;
        throw err;
    }
}

/**
 * 새 TBM 배포 세션을 생성합니다.
 * @param {object} payload - 날씨·엑셀·대본 데이터
 * @returns {Promise<object>} 생성된 세션
 */
async function createSession(payload) {
    await ensureStorage();
    const startedAt = Date.now();
    const id = payload.id || crypto.randomUUID();

    // 한국 시간(KST) 기준 날짜/시간 생성
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const ts = `${kst.getUTCFullYear()}-${pad(kst.getUTCMonth() + 1)}-${pad(kst.getUTCDate())}_${pad(kst.getUTCHours())}${pad(kst.getUTCMinutes())}${pad(kst.getUTCSeconds())}`;

    const rawTitle = payload.workTitle || (payload.fileName ? path.basename(payload.fileName, path.extname(payload.fileName)) : '작업계획서');
    const cleanTitle = String(rawTitle).trim().replace(/[\\/:*?"<>|]/g, '_');

    let folderName = `[${ts}]_${cleanTitle}`;
    let folderDir = path.join(SESSIONS_DIR, folderName);
    let counter = 1;
    while (fs.existsSync(folderDir)) {
        folderName = `[${ts}]_${cleanTitle}_${counter++}`;
        folderDir = path.join(SESSIONS_DIR, folderName);
    }

    await fsp.mkdir(folderDir, { recursive: true });
    sessionFolderCache.set(id, folderName);
    const dir = folderDir;

    const record = {
        id,
        folderName,
        status: '배포됨',
        createdAt: new Date().toISOString(),
        completedAt: null,
        fileName: payload.fileName || '작업계획서',
        workTitle: payload.workTitle || payload.fileName || '오늘의 작업',
        workDate: payload.workDate || '',
        chemicalHazard: payload.chemicalHazard || '',
        chemicalProcess: payload.chemicalProcess || '',
        chemicals: payload.chemicals || '',
        briefingUrl: payload.briefingUrl || '',
        weather: payload.weather || '',
        weatherAlert: payload.weatherAlert || '',
        points: Array.isArray(payload.points) ? payload.points : [],
        script: payload.script || '',
        excelSheets: Array.isArray(payload.excelSheets) ? payload.excelSheets : [],
        signatures: [],
        hasAudio: false,
    };

    await writeMeta(record);
    await fsp.writeFile(path.join(dir, 'excel.csv'), payload.excelData || '', 'utf8');
    await fsp.writeFile(path.join(dir, 'tbm.txt'), payload.script || '', 'utf8');
    if (payload.originalBuffer) {
        const ext = path.extname(payload.originalName || payload.fileName || '').toLowerCase() === '.xls' ? '.xls' : '.xlsx';
        await fsp.writeFile(path.join(dir, `original${ext}`), payload.originalBuffer);
    }

    if (payload.briefingUrl) {
        const originalName = payload.originalName || payload.fileName || 'workplan.xlsx';
        const qrPng = await buildQrPng(payload.briefingUrl);
        await fsp.writeFile(path.join(dir, 'qr.png'), qrPng);
        if (payload.originalBuffer) {
            const stamped = await stampQrOnWorkplan(payload.originalBuffer, qrPng, originalName);
            const stampedBuffer = Buffer.from(stamped);
            await fsp.writeFile(path.join(dir, 'workplan-qr.xlsx'), stampedBuffer);
            const cleanTitle = (record.workTitle || '작업계획서').replace(/[\\/:*?"<>|]/g, '_');
            await fsp.writeFile(path.join(STORE_ROOT, `[작업계획서_QR]_${cleanTitle}.xlsx`), stampedBuffer);
            await fsp.writeFile(path.join(STORE_ROOT, '작업계획서_TBM_QR.xlsx'), stampedBuffer);
        }
    }

    await upsertIndex(toSummary(record));
    console.log(`[저장소] 세션 생성 id=${id}, 소요=${Date.now() - startedAt}ms`);
    return record;
}

/**
 * 저장된 세션 목록을 최신순으로 반환합니다.
 * @returns {Promise<object[]>} 목록
 */
async function listSessions() {
    await ensureStorage();
    try {
        const list = JSON.parse(await fsp.readFile(INDEX_PATH, 'utf8'));
        if (!Array.isArray(list)) return [];
        return list.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    } catch (err) {
        console.error('[저장소] 목록 읽기 실패:', err.message);
        return [];
    }
}

/**
 * 세션 상세와 작업계획서 CSV를 함께 반환합니다.
 * @param {string} id - 세션 ID
 * @param {{includeImages?: boolean}} options - 서명 이미지 포함 여부
 * @returns {Promise<object|null>} 상세 또는 null
 */
async function getSessionDetail(id, options = {}) {
    const record = await readSession(id);
    if (!record) return null;

    let excelCsv = '';
    try {
        excelCsv = await fsp.readFile(path.join(sessionDir(id), 'excel.csv'), 'utf8');
    } catch (err) {
        console.warn(`[저장소] 엑셀 CSV 없음 id=${id}:`, err.message);
    }

    const signatures = [];
    for (const item of record.signatures || []) {
        const copied = { ...item };
        if (options.includeImages && item.imageFile) {
            try {
                const buf = await fsp.readFile(path.join(sessionDir(id), item.imageFile));
                copied.imageDataUrl = `data:image/png;base64,${buf.toString('base64')}`;
            } catch (err) {
                console.warn(`[저장소] 서명 이미지 없음 ${item.imageFile}:`, err.message);
            }
        }
        signatures.push(copied);
    }

    return { ...record, signatures, excelCsv, hasAudio: sessionHasAudio(id) };
}

/**
 * data URL을 PNG 버퍼로 변환합니다.
 * @param {string} dataUrl - PNG data URL
 * @returns {Buffer} 이미지 버퍼
 */
function pngBufferFromDataUrl(dataUrl) {
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/png;base64,')) {
        throw new Error('서명 이미지 형식이 올바르지 않습니다.');
    }
    return Buffer.from(dataUrl.replace('data:image/png;base64,', ''), 'base64');
}

/**
 * 서명을 저장하고 세션을 완료 처리합니다.
 * @param {string} id - 세션 ID
 * @param {object[]} signatures - 이름·서명 이미지 배열
 * @param {{completedAt?: string}} [options] - 원격 완료 시각 유지용
 * @returns {Promise<object>} 완료된 세션
 */
async function completeSession(id, signatures, options = {}) {
    const startedAt = Date.now();
    const record = await readSession(id);
    if (!record) {
        const err = new Error('세션을 찾을 수 없습니다.');
        err.statusCode = 404;
        throw err;
    }
    const list = Array.isArray(signatures) ? signatures : [];
    if (record.status !== '완료' && list.length === 0) {
        const err = new Error('서명이 필요합니다.');
        err.statusCode = 400;
        throw err;
    }

    const dir = sessionDir(id);
    const saved = [];
    for (let i = 0; i < list.length; i++) {
        const item = list[i];
        const name = String(item.name || '').trim();
        if (!name) {
            const err = new Error('서명자 이름을 모두 입력해주세요.');
            err.statusCode = 400;
            throw err;
        }
        if (!item.imageDataUrl) {
            const err = new Error('이름과 서명이 모두 필요합니다.');
            err.statusCode = 400;
            throw err;
        }
        const imageFile = `signature-${String(i + 1).padStart(2, '0')}.png`;
        await fsp.writeFile(path.join(dir, imageFile), pngBufferFromDataUrl(item.imageDataUrl));
        saved.push({
            name,
            signedAt: item.signedAt || new Date().toISOString(),
            imageFile,
        });
    }

    try {
        const files = await fsp.readdir(dir);
        const keep = new Set(saved.map((item) => item.imageFile));
        await Promise.all(files
            .filter((file) => /^signature-\d+\.png$/i.test(file) && !keep.has(file))
            .map((file) => fsp.unlink(path.join(dir, file))));
    } catch (err) {
        console.warn(`[저장소] 이전 서명 파일 정리 실패 id=${id}:`, err.message);
    }

    record.signatures = saved;
    record.status = '완료';
    record.completedAt = options.completedAt || new Date().toISOString();
    record.cancelledAt = null;
    await writeMeta(record);
    await upsertIndex(toSummary(record));
    console.log(`[저장소] 서명 저장 id=${id}, 서명=${saved.length}명, 소요=${Date.now() - startedAt}ms`);
    return record;
}

/**
 * 로컬 서명이 원격과 다른지 확인합니다.
 * @param {object} local - 로컬 세션
 * @param {object} remote - Vercel 세션
 * @returns {boolean} 다르면 true
 */
function signaturesNeedUpdate(local, remote) {
    if (!local || local.status !== '완료') return true;
    if (String(local.completedAt || '') !== String(remote.completedAt || '')) return true;
    const a = local.signatures || [];
    const b = remote.signatures || [];
    if (a.length !== b.length) return true;
    return a.some((item, idx) => String(item.name || '') !== String((b[idx] && b[idx].name) || ''));
}

/**
 * Vercel에서 완료된 서명을 로컬 이력으로 가져옵니다.
 * @param {string} id - 세션 ID
 * @param {object} remote - Vercel 세션
 * @returns {Promise<boolean>} 갱신했으면 true
 */
async function importRemoteCompletion(id, remote) {
    if (!remote) return false;
    const local = await readSession(id);
    if (!local) return false;
    if (remote.status === '완료') {
        if (!signaturesNeedUpdate(local, remote)) return false;
        await completeSession(id, remote.signatures || [], { completedAt: remote.completedAt });
        return true;
    }
    if (local.status === '완료') {
        return revertSessionSubmission(id);
    }
    return false;
}

/**
 * 제출을 취소하고 관리 페이지에서 완료 이력을 뺍니다.
 * @param {string} id - 세션 ID
 * @returns {Promise<object>} 갱신된 세션
 */
async function revertSessionSubmission(id) {
    const record = await readSession(id);
    if (!record) {
        const err = new Error('세션을 찾을 수 없습니다.');
        err.statusCode = 404;
        throw err;
    }
    if (record.status !== '완료') {
        const err = new Error('제출된 TBM이 없습니다.');
        err.statusCode = 400;
        throw err;
    }

    const dir = sessionDir(id);
    try {
        const files = await fsp.readdir(dir);
        await Promise.all(files
            .filter((file) => /^signature-\d+\.png$/i.test(file))
            .map((file) => fsp.unlink(path.join(dir, file))));
    } catch (err) {
        console.warn(`[저장소] 서명 파일 삭제 실패 id=${id}:`, err.message);
    }

    record.signatures = [];
    record.status = '배포됨';
    record.completedAt = null;
    record.cancelledAt = new Date().toISOString();
    await writeMeta(record);
    await upsertIndex(toSummary(record));
    console.log(`[저장소] 제출 취소 id=${id}`);
    return record;
}

/**
 * 세션 폴더의 QR·작업계획서 파일 경로를 반환합니다.
 * @param {string} id - 세션 ID
 * @param {'qr'|'workplan'} kind - 파일 종류
 * @returns {string} 절대 경로
 */
function sessionAssetPath(id, kind) {
    if (kind === 'qr') return path.join(sessionDir(id), 'qr.png');
    if (kind === 'audio') return path.join(sessionDir(id), 'tbm.mp3');
    return path.join(sessionDir(id), 'workplan-qr.xlsx');
}

/**
 * 세션에 InJoon 음성 mp3가 있는지 확인합니다.
 * @param {string} id - 세션 ID
 * @returns {boolean} 있으면 true
 */
function sessionHasAudio(id) {
    return fs.existsSync(sessionAssetPath(id, 'audio'));
}

/**
 * 세션 폴더에 음성 mp3를 저장합니다.
 * @param {string} id - 세션 ID
 * @param {Buffer} buffer - mp3
 * @returns {Promise<void>}
 */
async function saveSessionAudio(id, buffer) {
    await fsp.writeFile(sessionAssetPath(id, 'audio'), buffer);
    const record = await readSession(id);
    if (record) {
        record.hasAudio = true;
        await writeMeta(record);
        await upsertIndex(toSummary(record));
    }
}

/**
 * 저장된 세션의 QR 주소를 이 PC 서버 주소로 다시 만듭니다.
 * @param {(id: string) => string} urlForId - 세션 ID → 브리핑 URL
 * @returns {Promise<number>} 갱신한 건수
 */
async function refreshBriefingLinks(urlForId) {
    await ensureStorage();
    const list = await listSessions();
    let updated = 0;
    for (const item of list) {
        const record = await readSession(item.id);
        if (!record) continue;
        const nextUrl = urlForId(record.id);
        if (!nextUrl) continue;
        record.briefingUrl = nextUrl;
        await writeMeta(record);
        await fsp.writeFile(path.join(sessionDir(record.id), 'tbm.txt'), record.script || '', 'utf8');
        const qrPng = await buildQrPng(nextUrl);
        await fsp.writeFile(path.join(sessionDir(record.id), 'qr.png'), qrPng);
        updated += 1;
    }
    return updated;
}

/**
 * 세션 폴더 및 인덱스에서 세션을 완전히 삭제합니다.
 * @param {string} id - 세션 ID
 * @returns {Promise<boolean>} 성공 시 true
 */
async function deleteSession(id) {
    await ensureStorage();
    const dir = sessionDir(id);
    if (fs.existsSync(dir)) {
        await fsp.rm(dir, { recursive: true, force: true });
    }

    // index.json 갱신
    try {
        let list = JSON.parse(await fsp.readFile(INDEX_PATH, 'utf8'));
        if (Array.isArray(list)) {
            list = list.filter((item) => item.id !== id);
            await fsp.writeFile(INDEX_PATH, JSON.stringify(list, null, 2), 'utf8');
        }
    } catch (err) {
        console.warn('[저장소] 인덱스 삭제 실패:', err.message);
    }

    // 메모리 캐시 삭제
    sessionFolderCache.delete(id);
    console.log(`[저장소] 세션 삭제 완료 id=${id}`);
    return true;
}

module.exports = {
    STORE_ROOT,
    createSession,
    listSessions,
    getSessionDetail,
    completeSession,
    revertSessionSubmission,
    importRemoteCompletion,
    sessionAssetPath,
    sessionHasAudio,
    saveSessionAudio,
    refreshBriefingLinks,
    deleteSession,
};
