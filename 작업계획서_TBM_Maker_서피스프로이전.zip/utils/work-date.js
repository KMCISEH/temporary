/**
 * 작업계획서에서 작업 일시(날짜)를 추출하고 다양한 띄어쓰기/형식을 정규화합니다.
 */

const DATE_KEYS = /^(?:[\d\.\s\-\*]*)(?:작업\s*일시|작업\s*일자|작업\s*기간|공사\s*기간|일\s*시|일\s*자|기\s*간)(?:\s*\(.*?\))?/;
const TITLE_KEYS = /작업명|공사명|공종명|공종|작업\s*내용|작업\s*제목|제목/;
const DATE_CONTENT_PATTERN = /(?:2\s*0\s*[2-3]\s*\d|1\s*9\s*\d\s*\d|\d{2,4}\s*[\.\-\/]\s*\d{1,2}\s*[\.\-\/]\s*\d{1,2}|\d{1,2}\s*월\s*\d{1,2}\s*일)/;

/**
 * 숫자 사이의 불필요한 공백을 제거합니다.
 * 예: "20 26" -> "2026", "2 0 2 6" -> "2026", "0 9 월" -> "09월"
 * @param {string} str
 * @returns {string}
 */
function cleanSpacesBetweenDigits(str) {
    if (!str) return '';
    let s = String(str);
    // 4자리 연도 공백 보정
    s = s.replace(/\b(19|20)\s+(\d{2})\b/g, '$1$2');
    s = s.replace(/\b(2)\s*(0)\s*([2-3])\s*(\d)\b/g, '$1$2$3$4');
    s = s.replace(/\b(1)\s*(9)\s*(\d)\s*(\d)\b/g, '$1$2$3$4');
    // 단위 앞의 쪼개진 숫자 보정
    s = s.replace(/(\d)\s+(\d)\s*(년|월|일|시|분)/g, '$1$2$3');
    s = s.replace(/(\d+)\s+(\d+)\s*년/g, '$1$2년');
    return s;
}

/**
 * 대충 작성되거나 띄어쓰기가 제각각인 날짜 문자열을 읽기 쉬운 한국어 형식으로 정규화합니다.
 * @param {string|number} raw - 원본 날짜 텍스트
 * @returns {string} 정규화된 날짜 (예: "2026년 9월 1일 ~")
 */
function normalizeWorkDate(raw) {
    if (raw == null) return '';
    let s = String(raw).trim();
    if (!s) return '';

    // 엑셀 날짜 시리얼 번호 (예: 45536)
    if (/^\d{5}$/.test(s)) {
        const num = parseInt(s, 10);
        if (num >= 35000 && num <= 65000) {
            const date = new Date((num - (25567 + 2)) * 86400 * 1000);
            return `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일`;
        }
    }

    // 1. 라벨 접두사 제거
    s = s.replace(/^[\d\.\s\-\*]*(?:작업\s*일시|작업\s*일자|작업\s*기간|공사\s*기간|일\s*시|일\s*자|기\s*간)(?:\s*\(.*?\))?\s*[:：\s]*/i, '').trim();

    // 2. 숫자 사이 공백 보정
    s = cleanSpacesBetweenDigits(s);

    // 3. 다중 공백 / 탭 정리
    s = s.replace(/[\t\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();

    // 4. "YYYY년 M월 D일" 정규화
    s = s.replace(/(\d{2,4})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일/g, (match, y, m, d) => {
        const year = y.length === 2 ? '20' + y : y;
        return `${year}년 ${parseInt(m, 10)}월 ${parseInt(d, 10)}일`;
    });

    // 5. "YYYY. M. D" / "YYYY-MM-DD" / "YYYY/MM/DD" 정규화
    s = s.replace(/(\d{2,4})\s*[\.\-\/]\s*(\d{1,2})\s*[\.\-\/]\s*(\d{1,2})\.?/g, (match, y, m, d) => {
        const year = y.length === 2 ? '20' + y : y;
        return `${year}년 ${parseInt(m, 10)}월 ${parseInt(d, 10)}일`;
    });

    // 6. 종료일 형식 정규화 (~ 9월 3일 등)
    s = s.replace(/([~～\-])\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일/g, (match, sep, m, d) => {
        return `~ ${parseInt(m, 10)}월 ${parseInt(d, 10)}일`;
    });
    s = s.replace(/([~～\-])\s*(\d{1,2})\s*[\.\-\/]\s*(\d{1,2})\.?/g, (match, sep, m, d) => {
        return `~ ${parseInt(m, 10)}월 ${parseInt(d, 10)}일`;
    });

    // 7. 시간 형식 공백 정리 (09 : 00 -> 09:00)
    s = s.replace(/(\d{1,2})\s*:\s*(\d{2})/g, '$1:$2');

    // 8. 물결표(~) 구분자 정리
    s = s.replace(/\s*([~～])\s*/g, ' ~ ');

    // 9. 물결표(~) 뒤에 종료일이나 다른 내용이 없으면 물결표 제거
    s = s.replace(/\s*~\s*$/, '').trim();

    // 10. 최종 연속 공백 정리
    s = s.replace(/\s+/g, ' ').trim();

    return s;
}

/**
 * 엑셀 시트 또는 행 배열에서 작업 일시를 찾아서 정규화해 반환합니다.
 * @param {Array} sheetsOrRows - 시트 목록 또는 2차원 행 배열
 * @returns {string} 추출 및 정규화된 작업일시
 */
function extractWorkDate(sheetsOrRows) {
    const rows = [];
    if (Array.isArray(sheetsOrRows)) {
        sheetsOrRows.forEach((item) => {
            if (Array.isArray(item)) {
                rows.push(item);
            } else if (item && Array.isArray(item.preview)) {
                item.preview.forEach((r) => rows.push(r));
            } else if (item && Array.isArray(item.rows)) {
                item.rows.forEach((r) => rows.push(r));
            }
        });
    }

    // 1단계: "작업 일시", "일시" 등의 라벨이 있는 행 탐색
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i] || [];
        for (let j = 0; j < row.length; j++) {
            const cell = String(row[j] || '').trim();
            if (!cell) continue;

            if (DATE_KEYS.test(cell)) {
                // 케이스 A: 같은 셀 안에 날짜도 함께 적힌 경우
                if (DATE_CONTENT_PATTERN.test(cell)) {
                    const norm = normalizeWorkDate(cell);
                    if (norm) return norm;
                }

                // 케이스 B: 같은 행의 오른쪽 셀들 (병합된 빈 셀 건너뛰기)
                for (let k = j + 1; k < row.length; k++) {
                    const val = String(row[k] || '').trim();
                    if (val && !DATE_KEYS.test(val) && !TITLE_KEYS.test(val)) {
                        const norm = normalizeWorkDate(val);
                        if (norm) return norm;
                    }
                }

                // 케이스 C: 다음 행의 같은 열 또는 다음 유효 셀 탐색
                if (rows[i + 1]) {
                    const belowRow = rows[i + 1];
                    for (let k = j; k < belowRow.length; k++) {
                        const val = String(belowRow[k] || '').trim();
                        if (val && !DATE_KEYS.test(val) && !TITLE_KEYS.test(val)) {
                            const norm = normalizeWorkDate(val);
                            if (norm) return norm;
                        }
                    }
                }
            }
        }
    }

    // 2단계: 명시적 라벨이 없더라도 상위 35개 행에서 날짜 패턴 탐색
    const maxScan = Math.min(rows.length, 35);
    for (let i = 0; i < maxScan; i++) {
        const row = rows[i] || [];
        for (let j = 0; j < row.length; j++) {
            const cell = String(row[j] || '').trim();
            if (!cell || TITLE_KEYS.test(cell)) continue;
            if (DATE_CONTENT_PATTERN.test(cell)) {
                const norm = normalizeWorkDate(cell);
                if (norm) return norm;
            }
        }
    }

    return '';
}

module.exports = {
    normalizeWorkDate,
    extractWorkDate,
    cleanSpacesBetweenDigits,
};
