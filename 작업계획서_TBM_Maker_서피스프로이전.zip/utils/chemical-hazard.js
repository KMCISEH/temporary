/**
 * 작업계획서의 해당 공정 및 취급 화학물질을 분석하고 매핑합니다.
 */

const PROCESS_CONFIG = [
    { key: "AO공정", name: "AO공정", match: /AO\s*공정/i, chemicals: ["아닐린", "수소", "니트로벤젠"] },
    { key: "MDA공정", name: "MDA공정", match: /MDA\s*공정/i, chemicals: ["MDA"] },
    { key: "MDI합성", name: "MDI합성", match: /MDI\s*합성/i, chemicals: ["포스겐", "MDI", "ODCB"] },
    { key: "MDI정제", name: "MDI정제", match: /MDI\s*정제/i, chemicals: ["MDI"] },
    { key: "HCl", name: "HCl", match: /(?:\bHCl\b|염산)/i, chemicals: ["염산"] },
    { key: "FOX", name: "FOX", match: /\bFOX\b/i, chemicals: ["염소"] },
    { key: "CA", name: "CA", match: /\bCA\b/i, chemicals: ["염소", "가성소다"] },
];

/**
 * CSV 텍스트 또는 2D 시트 배열에서 체크된 해당 공정을 추출하고 취급 화학물질을 반환합니다.
 * @param {string|Array} input - CSV 텍스트 또는 시트 행 배열
 * @returns {{hasProcess: boolean, processes: string[], processNames: string, chemicals: string[], chemicalNames: string, summary: string}}
 */
function extractProcessChemicals(input) {
    const matched = [];

    if (Array.isArray(input)) {
        for (const row of input) {
            if (!Array.isArray(row)) continue;
            const rowStr = row.map(c => String(c || "")).join(" ");
            if (!/(?:해당\s*공정|1공장|2공장)/i.test(rowStr)) continue;

            for (const cell of row) {
                const s = String(cell || "").trim();
                if (!s) continue;
                const tokens = s.split(/(?=[□■▣☑◆●★◇○☆]|\[\s*[^\n\r\]]*\s*\])/);
                for (const token of tokens) {
                    const trimmed = token.trim();
                    const isChecked = /^[■▣☑◆●★]|^\s*\[\s*[vVxXoO\*\+]\s*\]/.test(trimmed);
                    const isUnchecked = /^[□◇○☆]|^\s*\[\s*[\s_]?\s*\]/.test(trimmed);
                    if (isChecked && !isUnchecked) {
                        for (const item of PROCESS_CONFIG) {
                            if (item.match.test(trimmed) && !matched.some(m => m.key === item.key)) {
                                matched.push(item);
                            }
                        }
                    }
                }
            }

            for (let c = 0; c < row.length; c++) {
                const cellVal = String(row[c] || "").trim();
                if (/^[■▣☑◆●★]$|^\[\s*[vVxXoO\*\+]\s*\]$/.test(cellVal)) {
                    for (let n = c + 1; n < Math.min(row.length, c + 5); n++) {
                        const nextVal = String(row[n] || "").trim();
                        if (nextVal) {
                            for (const item of PROCESS_CONFIG) {
                                if (item.match.test(nextVal) && !matched.some(m => m.key === item.key)) {
                                    matched.push(item);
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
    }

    const text = typeof input === "string" ? input : JSON.stringify(input);
    const lines = text.split(/[\r\n]+/);
    for (const line of lines) {
        if (!/(?:해당\s*공정|1공장|2공장)/i.test(line)) continue;

        const tokens = line.split(/(?=[□■▣☑◆●★◇○☆]|\[\s*[^\n\r\]]*\s*\])/);
        for (const token of tokens) {
            const trimmed = token.trim();
            if (!trimmed) continue;
            const isChecked = /^[■▣☑◆●★]|^\s*\[\s*[vVxXoO\*\+]\s*\]/.test(trimmed);
            const isUnchecked = /^[□◇○☆]|^\s*\[\s*[\s_]?\s*\]/.test(trimmed);

            if (isChecked && !isUnchecked) {
                for (const item of PROCESS_CONFIG) {
                    if (item.match.test(trimmed) && !matched.some(m => m.key === item.key)) {
                        matched.push(item);
                    }
                }
            }
        }
    }

    if (matched.length === 0) {
        for (const line of lines) {
            if (/(?:해당\s*공정|1공장|2공장)/i.test(line)) continue;
            for (const item of PROCESS_CONFIG) {
                if (item.match.test(line) && !matched.some(m => m.key === item.key)) {
                    matched.push(item);
                }
            }
        }
    }

    const chemicals = [];
    matched.forEach(m => {
        m.chemicals.forEach(c => {
            if (!chemicals.includes(c)) chemicals.push(c);
        });
    });

    return {
        hasProcess: matched.length > 0,
        processes: matched.map(m => m.name),
        processNames: matched.map(m => m.name).join(", "),
        chemicals,
        chemicalNames: chemicals.join(", "),
        summary: matched.length > 0 ? (matched.map(m => m.name).join(", ") + " (" + chemicals.join(", ") + ")") : ""
    };
}

module.exports = {
    PROCESS_CONFIG,
    extractProcessChemicals
};
