/**
 * 업로드된 작업계획서 원본을 파일명 그대로 보관합니다.
 */

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');

const UPLOADS_DIR = path.join(__dirname, '..', 'tbm-store', 'uploads');

/**
 * 윈도우 파일 시스템에 안전한 파일명을 만듭니다.
 * @param {string} fileName - 원본 파일명
 * @returns {string} 정제된 파일명
 */
function sanitizeFileName(fileName) {
    const raw = String(fileName || '작업계획서.xlsx').trim();
    return raw.replace(/[\\/:*?"<>|]/g, '_');
}

/**
 * 원본 엑셀을 파일명 그대로 저장하고 uploadId(파일명)를 반환합니다.
 * 동일한 파일명이 이미 존재할 경우 시각 접두어를 붙여 덮어쓰기를 방지합니다.
 * @param {Buffer} buffer - 파일 버퍼
 * @param {string} fileName - 원본 파일명
 * @returns {Promise<{uploadId: string}>}
 */
async function saveUpload(buffer, fileName) {
    await fsp.mkdir(UPLOADS_DIR, { recursive: true });

    let targetName = sanitizeFileName(fileName);
    if (!targetName.toLowerCase().endsWith('.xlsx') && !targetName.toLowerCase().endsWith('.xls')) {
        targetName += '.xlsx';
    }

    let filePath = path.join(UPLOADS_DIR, targetName);
    if (fs.existsSync(filePath)) {
        const now = new Date();
        const pad = (n) => String(n).padStart(2, '0');
        const ts = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
        targetName = `[${ts}]_${targetName}`;
        filePath = path.join(UPLOADS_DIR, targetName);
    }

    await fsp.writeFile(filePath, buffer);
    return { uploadId: targetName };
}

/**
 * 업로드된 원본 버퍼를 읽습니다. (단일 파일 및 구형 UUID 폴더 모두 호환)
 * @param {string} uploadId - 업로드 파일명 또는 레거시 폴더명
 * @returns {Promise<{buffer: Buffer, fileName: string}|null>}
 */
async function readUpload(uploadId) {
    if (!uploadId) return null;

    const targetPath = path.join(UPLOADS_DIR, uploadId);
    try {
        const stat = await fsp.stat(targetPath);
        if (stat.isFile()) {
            const buffer = await fsp.readFile(targetPath);
            const cleanOriginalName = uploadId.replace(/^\[\d{8}_\d{6}\]_/, '');
            return { buffer, fileName: cleanOriginalName };
        } else if (stat.isDirectory()) {
            const metaPath = path.join(targetPath, 'meta.json');
            let metaName = 'workplan.xlsx';
            let ext = '.xlsx';
            if (fs.existsSync(metaPath)) {
                try {
                    const meta = JSON.parse(await fsp.readFile(metaPath, 'utf8'));
                    metaName = meta.fileName || metaName;
                    ext = meta.ext || ext;
                } catch (_) {}
            }
            const origPath = path.join(targetPath, `original${ext}`);
            const buffer = await fsp.readFile(origPath);
            return { buffer, fileName: metaName };
        }
    } catch (err) {
        if (err.code === 'ENOENT') return null;
        throw err;
    }

    return null;
}

module.exports = { saveUpload, readUpload };

