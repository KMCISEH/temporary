/**
 * 작업반장용 공개 브리핑 주소와 통신합니다.
 * 작업계획서 원본은 이 컴퓨터에만 두고, 제목·대본·서명만 공개 호스트로 보냅니다.
 */

const { getLanAddresses } = require('./network');

if (process.env.ALLOW_INSECURE_TLS === '1') {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
}

function publicBaseUrl() {
    const raw = String(process.env.PUBLIC_APP_URL || '').replace(/\/$/, '');
    if (!raw || raw.includes('여기에')) return '';
    return raw;
}

function publicSecret() {
    const secret = process.env.TBM_API_SECRET || process.env.PUBLIC_API_SECRET || '';
    if (!secret || secret.includes('여기에')) return '';
    return secret;
}

function isPublicHostConfigured() {
    return Boolean(publicBaseUrl() && publicSecret());
}

function mobileUrl(id) {
    const base = publicBaseUrl();
    if (!base || !id) return '';
    return `${base}/m/${id}`;
}

/**
 * QR에 넣을 반장용 주소를 정합니다. Vercel이 있으면 그걸 쓰고, 없으면 같은 Wi-Fi 주소를 씁니다.
 * @param {string} id - 세션 ID
 * @returns {string} 브리핑 URL
 */
function briefingUrl(id, port) {
    const published = mobileUrl(id);
    if (published) return published;
    const usePort = port || process.env.PORT || 3000;
    const lan = getLanAddresses()[0];
    if (lan) return `http://${lan.address}:${usePort}/m/${id}`;
    return `http://localhost:${usePort}/m/${id}`;
}

const getBriefingUrl = briefingUrl;

/**
 * 로컬 세션을 Vercel에 올립니다. 설정이 없으면 건너뜁니다.
 * @param {object} session - 로컬 세션
 * @returns {Promise<{id: string, volatile?: boolean}|null>}
 */
async function publishSession(session) {
    if (!isPublicHostConfigured()) return null;

    const res = await fetch(`${publicBaseUrl()}/api/sessions`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-tbm-secret': publicSecret(),
        },
        body: JSON.stringify({
            id: session.id,
            createdAt: session.createdAt,
            fileName: session.fileName,
            workTitle: session.workTitle,
            workDate: session.workDate || '',
            chemicalHazard: session.chemicalHazard || '',
            chemicalProcess: session.chemicalProcess || '',
            weather: session.weather,
            weatherAlert: session.weatherAlert,
            points: session.points,
            script: session.script,
            hasAudio: Boolean(session.hasAudio),
        }),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        const err = new Error(data.error || 'Vercel 배포에 실패했습니다.');
        err.statusCode = res.status;
        throw err;
    }
    if (data.volatile) {
        throw new Error('Vercel 임시 저장만 되어 반장 휴대폰에서 TBM을 다시 열 수 없습니다.');
    }
    return data;
}

/**
 * 인준 음성 mp3를 Vercel에 올립니다.
 * @param {string} id - 세션 ID
 * @param {Buffer} buffer - mp3
 * @returns {Promise<boolean>} 성공 여부
 */
async function publishAudio(id, buffer) {
    if (!isPublicHostConfigured() || !id || !buffer || !buffer.length) return false;
    const res = await fetch(`${publicBaseUrl()}/api/sessions/${id}/audio`, {
        method: 'POST',
        headers: {
            'Content-Type': 'audio/mpeg',
            'x-tbm-secret': publicSecret(),
        },
        body: buffer,
    });
    if (!res.ok) {
        const text = await res.text().catch(() => '');
        let data = {};
        try { data = JSON.parse(text); } catch { /* HTML 오류 페이지 */ }
        throw new Error(data.error || `음성 업로드 실패 (${res.status})`);
    }
    return true;
}

/**
 * Vercel에 저장된 세션을 가져옵니다.
 * @param {string} id - 세션 ID
 * @returns {Promise<object|null>}
 */
async function fetchPublicSession(id) {
    if (!isPublicHostConfigured()) return null;
    const res = await fetch(`${publicBaseUrl()}/api/admin/sessions/${id}`, {
        headers: { 'x-tbm-secret': publicSecret() },
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        console.warn(`[Vercel] 세션 조회 실패 id=${id}:`, data.error || res.status);
        return null;
    }
    return data;
}

/**
 * Vercel에 저장된 세션을 취소(초기화)합니다.
 * @param {string} id - 세션 ID
 * @returns {Promise<boolean>}
 */
async function cancelPublicSession(id) {
    if (!isPublicHostConfigured() || !id) return false;
    try {
        const res = await fetch(`${publicBaseUrl()}/api/sessions/${id}/cancel`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-tbm-secret': publicSecret(),
            },
        });
        return res.ok;
    } catch (err) {
        console.warn(`[Vercel 제출 취소 동기화 실패] id=${id}:`, err.message);
        return false;
    }
}

module.exports = {
    publicBaseUrl,
    isPublicHostConfigured,
    briefingUrl,
    getBriefingUrl,
    mobileUrl,
    publishSession,
    fetchPublicSession,
    publishAudio,
    cancelPublicSession,
};
