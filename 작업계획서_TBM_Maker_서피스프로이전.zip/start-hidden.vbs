Option Explicit
Dim fso, sh, root
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = root

If Not fso.FileExists(root & "\.env") Then
    WScript.Quit 1
End If

If Not fso.FolderExists(root & "\node_modules") Then
    sh.Run "cmd /c npm install", 0, True
End If

If PortInUse(3000) Then
    WScript.Quit 0
End If

sh.Run "cmd /c node server.js", 0, False
WScript.Quit 0

Function PortInUse(port)
    Dim exec, out
    Set exec = sh.Exec("cmd /c netstat -ano ^| findstr "":" & port & """ ^| findstr LISTENING")
    out = exec.StdOut.ReadAll()
    PortInUse = (Len(Trim(out)) > 0)
End Function
