@echo off
chcp 65001 >nul
set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\TBM-server.lnk"
if exist "%LNK%" (
    del /f /q "%LNK%"
    echo 자동 시작을 해제했습니다.
) else (
    echo 등록된 자동 시작이 없습니다.
)
pause
