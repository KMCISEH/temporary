Option Explicit
Dim fso, sh, root, startup, dest, lnk
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
startup = sh.SpecialFolders("Startup")
If Len(startup) = 0 Then
    WScript.Quit 1
End If

dest = startup & "\TBM-server.lnk"
Set lnk = sh.CreateShortcut(dest)
lnk.TargetPath = root & "\start-hidden.vbs"
lnk.WorkingDirectory = root
lnk.WindowStyle = 7
lnk.Save
WScript.Echo dest
WScript.Quit 0
