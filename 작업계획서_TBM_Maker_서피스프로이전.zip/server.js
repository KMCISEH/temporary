/**
 * 스마트 TBM 생성기 — Express 서버
 * 
 * 역할:
 * 1. 프론트엔드 정적 파일 서빙 (public/)
 * 2. /api/weather — 기상청 API 프록시 (키 보호)
 * 3. /api/parse-excel — 엑셀 파싱 (서버사이드)
 * 4. /api/generate-tbm — Gemini API 프록시 (키 보호)
 * 5. /api/sessions — 모바일 배포·서명 취합·로컬 이력 저장
 */

require('dotenv').config();
if (process.env.ALLOW_INSECURE_TLS === '1') {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
}

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const XLSX = require('xlsx');
const { buildWeatherSummary } = require('./utils/weather');
const { createSession, listSessions, getSessionDetail, completeSession, revertSessionSubmission, importRemoteCompletion, sessionAssetPath, refreshBriefingLinks, STORE_ROOT, saveSessionAudio, sessionHasAudio, deleteSession } = require('./utils/storage');
const { isPublicHostConfigured, briefingUrl, publishSession, fetchPublicSession, publicBaseUrl, publishAudio, cancelPublicSession } = require('./utils/public-host');
const { saveUpload, readUpload } = require('./utils/uploads');
const { extractWorkTitle } = require('./utils/work-title');
const { extractWorkDate } = require('./utils/work-date');
const { extractProcessChemicals } = require('./utils/chemical-hazard');
const { synthesizeInJoonMp3 } = require('./utils/edge-tts');

const app = express();
const PORT = process.env.PORT || 3000;

// ── 미들웨어 ──
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// 파일 업로드 (메모리 저장, 10MB 제한)
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// ── 환경변수 검증 ──
function checkEnvVars() {
    const missing = [];
    if (!process.env.KMA_API_KEY || process.env.KMA_API_KEY.includes('여기에')) missing.push('KMA_API_KEY');
    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY.includes('여기에')) missing.push('GEMINI_API_KEY');
    
    if (missing.length > 0) {
        console.warn('');
        console.warn('⚠️  다음 환경변수가 설정되지 않았습니다:');
        missing.forEach(key => console.warn(`   - ${key}`));
        console.warn('');
        console.warn('   .env.example 파일을 참고하여 .env 파일을 생성해주세요.');
        console.warn('');
    }
    return missing;
}

const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-flash-lite-latest';
const EXCEL_CSV_MAX_CHARS = 12000;

/**
 * 빈 행을 제거하고 Gemini 입력 길이를 제한합니다.
 * @param {string} csvData - 작업계획서 CSV 원문
 * @returns {string} 압축·절단된 CSV
 */
function trimExcelCsv(csvData) {
    if (typeof csvData !== 'string') return '';

    const compact = csvData
        .split('\n')
        .filter((row) => row.replace(/,/g, '').trim() !== '')
        .join('\n');

    if (compact.length <= EXCEL_CSV_MAX_CHARS) return compact;
    return compact.slice(0, EXCEL_CSV_MAX_CHARS) + '\n...(이하 생략)';
}

/**
 * TBM 대본을 문장 단위로 나눕니다. 소수점(31.2)은 문장 끝으로 보지 않습니다.
 * @param {string} text - 공백이 정리된 대본
 * @returns {string[]} 문장 배열
 */
function splitKoreanSentences(text) {
    const prepared = String(text || '')
        .replace(/([.!?。])\s*(둘째|셋째|두\s*번째|세\s*번째)\s*/g, '$1 $2 ')
        .replace(/([^\s.!?。])\s+(둘째|셋째|두\s*번째|세\s*번째)\s*/g, '$1. $2 ');
    const parts = [];
    let buf = '';

    for (let i = 0; i < prepared.length; i++) {
        const ch = prepared[i];
        buf += ch;

        if (ch === '!' || ch === '?' || ch === '。') {
            parts.push(buf.trim());
            buf = '';
            continue;
        }

        if (ch === '.') {
            const prev = prepared[i - 1];
            const next = prepared[i + 1];
            if (prev && /\d/.test(prev) && next && /\d/.test(next)) continue;
            parts.push(buf.trim());
            buf = '';
        }
    }

    if (buf.trim()) parts.push(buf.trim());
    return parts.filter(Boolean);
}

/**
 * 문장 끝에 마침표를 하나만 남깁니다.
 * @param {string} sentence - 한 문장
 * @returns {string} 마침표 하나인 문장
 */
function ensureSentencePeriod(sentence) {
    const trimmed = String(sentence || '')
        .replace(/\.{2,}/g, '.')
        .trim()
        .replace(/^[.!?。]+/, '')
        .replace(/[.!?。]+$/g, '')
        .trim();
    if (!trimmed) return '';
    return `${trimmed}.`;
}

/**
 * 한 문장마다 줄을 바꿉니다. 마침표는 문장당 하나만 둡니다.
 * @param {string} text - TBM 대본 원문
 * @returns {string} 문장별 줄바꿈 대본
 */
function normalizeScriptParagraphs(text) {
    if (typeof text !== 'string') return '';

    const compact = text
        .replace(/\r\n/g, '\n')
        .replace(/\n+/g, ' ')
        .replace(/[ \t]+/g, ' ')
        .replace(/\.{2,}/g, '.')
        .trim();
    const sentences = splitKoreanSentences(compact)
        .map((sentence) => ensureSentencePeriod(sentence))
        .filter(Boolean);
    return sentences.join('\n');
}

// ── API 라우트 ──

/**
 * GET /api/weather
 * 고정 현장(.env 좌표)의 기상청 3종 API를 호출하여 종합 날씨 데이터 반환
 */
app.get('/api/weather', async (req, res) => {
    const apiKey = process.env.KMA_API_KEY;
    if (!apiKey || apiKey.includes('여기에')) {
        return res.status(500).json({ error: '기상청 API 키가 설정되지 않았습니다. .env 파일을 확인해주세요.' });
    }

    const nx = parseInt(process.env.DEFAULT_NX) || 73;
    const ny = parseInt(process.env.DEFAULT_NY) || 66;
    const locationName = process.env.DEFAULT_LOCATION_NAME || 'KMCI';

    try {
        const weatherData = await buildWeatherSummary(apiKey, nx, ny);
        weatherData.locationName = locationName;
        res.json(weatherData);
    } catch (err) {
        console.error('[/api/weather] 오류:', err);
        res.status(500).json({ error: '날씨 데이터를 가져오는 중 오류가 발생했습니다.' });
    }
});

/**
 * POST /api/parse-excel
 * 업로드된 엑셀 파일을 서버에서 파싱하여 구조화된 데이터 반환
 */
app.post('/api/parse-excel', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: '엑셀 파일이 필요합니다.' });
    }

    try {
        const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
        const sheetNames = workbook.SheetNames;
        
        let allCsvData = '';
        const sheetPreviews = [];
        const allFilteredRows = [];

        sheetNames.forEach(name => {
            const sheet = workbook.Sheets[name];
            const csv = XLSX.utils.sheet_to_csv(sheet);
            allCsvData += csv + '\n';

            const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
            const filteredRows = jsonData.filter(row => row.some(cell => cell !== ''));
            allFilteredRows.push(...filteredRows);
            
            sheetPreviews.push({
                sheetName: name,
                rowCount: filteredRows.length,
                preview: filteredRows.slice(0, 8),
            });
        });

        let fileName = req.file.originalname;
        try {
            fileName = Buffer.from(req.file.originalname, 'latin1').toString('utf8');
        } catch (e) {
            fileName = req.file.originalname;
        }

        const { uploadId } = await saveUpload(req.file.buffer, fileName);
        const workTitle = extractWorkTitle(allFilteredRows.length > 0 ? allFilteredRows : sheetPreviews, fileName);
        const workDate = extractWorkDate(allFilteredRows.length > 0 ? allFilteredRows : sheetPreviews);
        const chemicalInfo = extractProcessChemicals(allFilteredRows.length > 0 ? allFilteredRows : sheetPreviews);

        res.json({
            uploadId,
            fileName,
            workTitle,
            workDate,
            chemicalInfo,
            sheetCount: sheetNames.length,
            sheets: sheetPreviews,
            csvData: allCsvData,
        });
    } catch (err) {
        console.error('[/api/parse-excel] 오류:', err);
        res.status(500).json({ error: '엑셀 파일 파싱 중 오류가 발생했습니다.' });
    }
});

/**
 * POST /api/generate-tbm
 * Gemini API 프록시 — 프론트엔드에서 보낸 날씨+엑셀 데이터로 TBM 대본 생성
 */
app.post('/api/generate-tbm', async (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey.includes('여기에')) {
        return res.status(500).json({ error: 'Gemini API 키가 설정되지 않았습니다. .env 파일을 확인해주세요.' });
    }

    const { weather, excelData, workDate } = req.body;

    if (!weather || !excelData) {
        return res.status(400).json({ error: '날씨 정보와 작업계획서 데이터가 필요합니다.' });
    }

    const excelForPrompt = trimExcelCsv(excelData);
    const chemicalInfo = extractProcessChemicals(excelData);

    const systemInstruction = `
[시스템 역할]
당신은 현장의 20년 차 베테랑 안전관리자 겸 작업반장입니다.
제공된 [오늘의 날씨]와 [작업계획서] 데이터를 분석하여, 당일 아침 TBM 시간에 작업자들 앞에서 직접 낭독할 '3분 안전 교육 대본'을 작성해 주세요.

[작성 지침]
어투: 딱딱한 문어체가 아닌, 현장 반장님이 직접 육성으로 말하는 듯한 자연스럽고 힘찬 구어체(~합시다, ~해주십시오)로 작성하세요.
날씨 브리핑: 대본 첫머리에 기상 특보를 반드시 언급하고 그에 맞는 안전/건강 주의사항을 당부하세요.
3대 핵심 포인트: 작업 내용 및 순서를 분석하여 오늘 가장 치명적인 위험 요인과 안전 대책 3가지를 선정해 번호를 매겨 강조하세요. 대본 본문에서는 반드시 '첫째', '둘째', '셋째'로 시작하고, 각 항목은 줄을 바꿔 따로 쓰세요.
보호구 점검 (데이터 추출 주의사항): 작업계획서의 '필요 안전보호장비' 항목에서 반드시 체크 표시(■)된 보호구만 필수 보호구로 간주하여 대본에 반영하세요. 선택되지 않은 항목(□)은 절대 포함하지 마십시오. 추출한 필수 보호구를 언급하며 옆 동료와 서로 착용 상태를 점검하도록 유도하세요.

[화학물질 인체 노출 위험성 분석 지침 (필수 및 절대 준수)]
1. 작업 환경 및 상황 인지 (매우 중요):
   - 본 작업은 작업자가 화학물질을 '직접 취급'하거나 '물질 자체를 직접 다루는' 작업이 아닙니다. ("오늘 공정에서 취급하는 [물질]은~", "물질을 취급할 때~" 같은 직접 취급 표현은 절대 사용하지 마십시오.)
   - 작업 구역(공정)의 배관, 탱크, 밸브 등 설비 내부에 해당 화학물질이 흐르거나 보관되어 있는 상황입니다.
   - 핵심 위험은 기기/배관 정비·점검·공사 중 혹시라도 발생할 수 있는 '불의의 물질 누출'로 인한 피부·눈 접촉 및 호흡기 흡입 노출입니다.

2. 문구 작성 및 행동 당부 요령:
   - "해당 공정 배관·설비 내부의 [물질명]이 혹시 누출되어 피부·눈에 접촉하거나 흡입할 경우 치명적 위험(피부/눈 심한 부식·화상, 호흡기 점막 손상·폐부종·급성 독성 등)이 발생할 수 있어 매우 위험하니, ~게 하라(~합시다, ~해주십시오)"는 구조로 구체적인 예방 행동 수칙을 강력히 당부하세요.
   - 필수 포함 안전 행동:
     ① 작업 전/작업 중 배관 연결부나 밸브 주변의 누출 징후(액체 고임, 가스 냄새, 압력 이상 등) 철저 확인
     ② 만약의 누출 비산에 대비한 지정 내화학 보호구(내화학 장갑/보호복) 및 전용 방독마스크 확실한 착용
     ③ 누출이나 이상 징후 발견 시 즉시 작업을 중단하고 바람 반대 방향으로 신속 대피
     ④ 신체 접촉 시 즉시 15분 이상 비상샤워기·세안기로 긴급 세척

[체크 공정별 공정 설비/배관 내 화학물질 기준]
1. AO공정 : 아닐린, 수소, 니트로벤젠
2. MDA공정 : MDA
3. MDI합성 : 포스겐, MDI, ODCB
4. MDI정제 : MDI
5. HCl : 염산
6. FOX : 염소
7. CA : 염소, 가성소다
(※ 체크된 공정이 복수일 경우 해당 물질들을 함께 반영하세요. 공정이 체크되지 않았거나 공무/기타 공정일 경우 일반 설비 배관 내 유해화학물질 누출 방지 및 비상 대응 수칙을 100자 내외로 포함하세요.)

[TBM 대본 내 반영 요령]
- 작업 내용 설명 및 보호구 착용 부분에 현장 반장님의 육성으로 100자 내외의 화학물질 누출 위험 경고 및 예방 조치 당부를 넣으세요. (직접 취급 표현 금지, 설비 누출 대비 수칙 강조)
  (예: "특히 오늘 작업하는 공정 배관과 탱크 내부에는 [물질명]이 흐르고 있어, 혹시라도 누출되어 피부나 눈에 닿으면 심한 부식과 화상을 입고 흡입 시 급성 독성을 일으켜 매우 위험합니다. 배관 주변 작업 시 누출 징후를 철저히 확인하고 지정된 내화학 보호구와 방독마스크를 확실히 착용하며, 이상 발생 시 즉시 바람 반대 방향으로 대피 후 15분 이상 비상샤워기로 세척합시다.")
- 가독성 및 문단: 한 문장이 끝나면 마침표를 하나만 찍고 줄을 바꾸세요. 마침표를 두 개 찍지 마세요. 빈 줄은 넣지 마세요. 첫째·둘째·셋째도 각각 한 줄입니다. 괄호 속 행동 지문이나 화면 특수기호는 넣지 말고, 입으로 낭독할 대사만 작성하세요.
- 분량 및 마무리: 화학물질 누출 위험 대비 수칙(100자 내외)이 포함되므로, 전체 TBM문구는 공백 포함 800자 이상 900자 이하로 작성하고, "오늘도 안전입니다." 같은 안전 구호로 마무리하세요. 900자를 넘기지 마세요.
- 작업제목: 작업계획서에서 오늘 실제 작업명을 짧게 뽑아 "작업제목" 필드에 넣으세요. 예: "회전기기 교반기 정비".
- 출력 형식: 프론트엔드 웹 앱에 바로 적용할 수 있도록 반드시 아래 JSON 포맷으로만 응답하세요. 마크다운 기호 없이 순수 JSON 텍스트만 출력해야 합니다.

[출력 JSON 포맷 예시]
{
"작업제목": "회전기기 교반기 정비",
"해당공정": "MDI합성",
"화학물질": "포스겐, MDI, ODCB",
"화학물질위험성": "MDI합성 공정 설비 및 배관 내부의 포스겐, MDI, ODCB는 작업 중 혹시 누출될 경우 피부·안구 부식 및 급성 폐부종 등 치명적 손상을 일으킬 수 있어 매우 위험합니다. 배관 연결부 누출 여부를 철저히 확인하고 전용 방독마스크와 내화학 보호구를 필수 착용하며, 노출 시 즉시 15분 이상 비상 세척하십시오.",
"날씨특보": "🚨 [폭염주의보] 틈틈이 그늘 휴식 및 수분 섭취 철저! (특보 없을 시 '없음')",
"핵심포인트": [
"1. 첫 번째 핵심 안전대책 (간결하게)",
"2. 두 번째 핵심 안전대책 (간결하게)",
"3. 세 번째 핵심 안전대책 (간결하게)"
],
"TBM문구": "자, 여러분 좋은 아침입니다.\\n오늘도 건강하게 모여주셔서 감사합니다.\\n먼저 오늘 날씨부터 확인합시다.\\n아침인데도 기온이 높으니 무리하지 말고 그늘 휴식과 수분 섭취를 철저히 합시다.\\n오늘 작업은 회전기기 정비입니다.\\n첫째, 회전체 정지 후 락아웃을 확인합시다.\\n둘째, 고소 작업 시 안전대를 체결합시다.\\n셋째, 중량물 이동 전 줄걸이를 재확인합시다.\\n오늘 작업하는 공정 배관과 설비 내부에는 포스겐과 MDI가 흐르고 있어, 혹시라도 누출되어 피부나 눈에 닿으면 심한 부식을 일으키고 흡입 시 급성 폐부종을 유발해 대단히 위험합니다. 배관 연결부 누출 여부를 수시로 확인하고 내화학 장갑과 전용 방독마스크를 철저히 착용하며, 이상 발생 시 즉시 바람 반대 방향으로 대피 후 비상샤워기로 15분간 세척합시다.\\n필요 보호구를 착용하고 옆 동료와 점검합시다.\\n오늘도 안전입니다."
}
`;

    const promptText = `
[데이터]
오늘의 날씨: ${weather}
${workDate ? `작업 일시: ${workDate}\n` : ''}${chemicalInfo.hasProcess ? `[해당 공정 분석 결과]\n체크된 공정: ${chemicalInfo.processNames}\n공정 배관·설비 내 주요 화학물질: ${chemicalInfo.chemicalNames}\n※ (주의: 물질 직접 취급 작업 아님) 공정 내 배관과 탱크 등에 존재하는 물질이 작업 중 혹시 누출되어 인체에 노출되었을 때의 위험성(피부·눈 부식/화상, 급성 독성 등)과 작업자가 지켜야 할 누출 예방/대비 및 응급 조치 수칙(~게 합시다/하십시오)을 100자 내외로 분석하여 TBM 대본과 '화학물질위험성' 필드에 반영해 주세요.\n` : ''}작업계획서 내용(CSV):
${excelForPrompt}
`;

    try {
        const startedAt = Date.now();
        const callGemini = async (modelName) => {
            const isLite = String(modelName).includes('lite');
            const thinkingLevel = isLite ? 'MINIMAL' : 'LOW';
            return fetch(
                `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        system_instruction: { parts: [{ text: systemInstruction }] },
                        contents: [{ parts: [{ text: promptText }] }],
                        generationConfig: {
                            response_mime_type: 'application/json',
                            maxOutputTokens: 2500,
                            thinkingConfig: { thinkingLevel },
                        },
                    }),
                }
            );
        };

        let activeModel = GEMINI_MODEL;
        let response = await callGemini(activeModel);

        // 만약 최신 모델(gemini-3.8-flash)에서 일시적인 503(수요 폭증) 또는 429 오류 발생 시 백업 모델로 즉시 자동 전환
        if (!response.ok && (response.status === 503 || response.status === 429) && activeModel !== 'gemini-flash-lite-latest') {
            console.warn(`[Gemini API] ${activeModel} 일시적 과부하(${response.status}), 초고속 백업 모델(gemini-flash-lite-latest)로 자동 전환합니다.`);
            activeModel = 'gemini-flash-lite-latest';
            response = await callGemini(activeModel);
        }

        if (!response.ok) {
            const errorText = await response.text();
            console.error('[Gemini API] 오류 응답:', errorText);
            return res.status(response.status).json({ error: 'Gemini API 호출에 실패했습니다. API 키를 확인해주세요.' });
        }

        const result = await response.json();
        const jsonText = result.candidates[0].content.parts[0].text;
        const data = JSON.parse(jsonText);
        if (data.TBM문구) {
            data.TBM문구 = normalizeScriptParagraphs(data.TBM문구);
        }
        if (Array.isArray(data.핵심포인트)) {
            data.핵심포인트 = data.핵심포인트.map((point) => ensureSentencePeriod(point));
        }
        if (data.화학물질위험성) {
            data.화학물질위험성 = ensureSentencePeriod(data.화학물질위험성);
        }
        if (!data.해당공정 && chemicalInfo.hasProcess) {
            data.해당공정 = chemicalInfo.processNames;
        }
        if (!data.화학물질 && chemicalInfo.hasProcess) {
            data.화학물질 = chemicalInfo.chemicalNames;
        }
        console.log(`[Gemini API] 모델=${GEMINI_MODEL}, 공정=${data.해당공정 || '미지정'}, 소요=${Date.now() - startedAt}ms`);

        res.json(data);
    } catch (err) {
        console.error('[/api/generate-tbm] 오류:', err);
        res.status(500).json({ error: '대본 생성 중 오류가 발생했습니다.' });
    }
});

/**
 * Vercel에 변경된 상태(서명 완료 또는 제출 취소)가 있으면 로컬 이력에 즉시 반영합니다.
 * @param {string} id - 세션 ID
 * @returns {Promise<void>}
 */
async function syncSessionFromPublic(id) {
    try {
        const remote = await fetchPublicSession(id);
        if (!remote) return;

        if (remote.status === '완료') {
            const updated = await importRemoteCompletion(id, remote);
            if (updated) console.log(`[저장소] Vercel 서명을 PC에 저장했습니다. id=${id}`);
        } else {
            const reverted = await importRemoteCompletion(id, remote);
            if (reverted) console.log(`[저장소] Vercel 제출 취소를 PC에 반영했습니다. id=${id}`);
        }
    } catch (err) {
        console.warn(`[Vercel 동기화] id=${id}:`, err.message);
    }
}

/**
 * 활성 세션(대기 중 및 최근 세션)을 선별하여 Vercel에서 서명 완료 또는 제출 취소를 확인하고 PC에 반영합니다.
 * @returns {Promise<void>}
 */
async function syncPendingSignatures() {
    if (!isPublicHostConfigured()) return;
    const current = await listSessions();
    const targetMap = new Map();
    // 1) 서명 대기('배포됨') 세션
    current.filter((item) => item.status === '배포됨').slice(0, 10).forEach((s) => targetMap.set(s.id, s));
    // 2) 최근 생성된 세션 상위 5건 (모바일에서 최근 제출 취소된 경우 즉시 감지)
    current.slice(0, 5).forEach((s) => targetMap.set(s.id, s));
    const targets = Array.from(targetMap.values());
    if (targets.length === 0) return;
    console.log(`[스마트 동기화] 활성/최근 세션 ${targets.length}건을 Vercel과 동기화합니다...`);
    await Promise.all(targets.map((item) => syncSessionFromPublic(item.id)));
}

/**
 * 인준 음성을 만들고 로컬·Vercel에 둡니다. 실패해도 TBM 배포는 계속합니다.
 * @param {object} session - 세션
 * @returns {Promise<boolean>} 음성 준비 여부
 */
async function attachInJoonAudio(session) {
    try {
        const fsp = require('fs').promises;
        let buffer;
        if (sessionHasAudio(session.id)) {
            buffer = await fsp.readFile(sessionAssetPath(session.id, 'audio'));
        } else {
            buffer = await synthesizeInJoonMp3(session.script);
            await saveSessionAudio(session.id, buffer);
        }
        session.hasAudio = true;
        if (isPublicHostConfigured()) {
            await publishAudio(session.id, buffer);
        }
        return true;
    } catch (err) {
        console.warn('[Edge TTS] 인준 음성 실패, 휴대폰 TTS로 대체합니다:', err.message);
        return false;
    }
}

/**
 * GET /api/network
 * 작업반장용 Vercel 공개 주소 반환
 */
app.get('/api/network', (req, res) => {
    res.json({
        publicAppUrl: publicBaseUrl(),
        configured: isPublicHostConfigured(),
    });
});

/**
 * POST /api/sessions
 * 로컬에 작업계획서·대본을 저장하고, 우측 하단 QR을 넣은 뒤 반장용 주소를 만듭니다.
 */
app.post('/api/sessions', async (req, res) => {
    const { weather, weatherAlert, points, script, excelData, excelSheets, fileName, uploadId, workTitle, workDate, chemicalHazard, chemicalProcess, chemicals } = req.body || {};
    if (!script || !excelData) {
        return res.status(400).json({ error: 'TBM 대본과 작업계획서가 필요합니다.' });
    }

    try {
        const id = crypto.randomUUID();
        const publicLink = briefingUrl(id);
        const upload = await readUpload(uploadId);
        const session = await createSession({
            id,
            weather,
            weatherAlert,
            points,
            script,
            excelData,
            excelSheets,
            fileName,
            workTitle: workTitle || extractWorkTitle(excelSheets, fileName),
            workDate: workDate || extractWorkDate(excelSheets) || '',
            chemicalHazard: chemicalHazard || '',
            chemicalProcess: chemicalProcess || '',
            chemicals: chemicals || '',
            briefingUrl: publicLink,
            originalBuffer: upload ? upload.buffer : null,
            originalName: upload ? upload.fileName : fileName,
        });

        let publishWarning = '';
        if (isPublicHostConfigured()) {
            try {
                await publishSession(session);
            } catch (err) {
                publishWarning = err.message;
                console.warn('[Vercel 배포] ', err.message);
            }
        }
        await attachInJoonAudio(session);

        res.json({
            id: session.id,
            status: session.status,
            workTitle: session.workTitle,
            workDate: session.workDate,
            chemicalHazard: session.chemicalHazard,
            chemicalProcess: session.chemicalProcess,
            briefingUrl: publicLink,
            usedVercel: isPublicHostConfigured() && !publishWarning,
            publishWarning,
            qrUrl: `/api/sessions/${session.id}/qr.png`,
            workplanUrl: `/api/sessions/${session.id}/workplan`,
        });
    } catch (err) {
        console.error('[/api/sessions] 생성 오류:', err);
        res.status(err.statusCode || 500).json({ error: err.message || '배포 세션을 만드는 중 오류가 발생했습니다.' });
    }
});

/**
 * GET /api/sessions
 * 데일리 TBM 목록
 */
app.get('/api/sessions', async (req, res) => {
    try {
        const forceSync = (req.query.sync === 'true');
        if (isPublicHostConfigured() && forceSync) {
            await syncPendingSignatures();
        }
        const list = await listSessions();
        res.json(list);
    } catch (err) {
        console.error('[/api/sessions] 목록 오류:', err);
        res.status(500).json({ error: '이력 목록을 불러오지 못했습니다.' });
    }
});

/**
 * GET /api/sessions/:id/qr.png
 * 작업계획서에 붙인 QR 이미지
 */
app.get('/api/sessions/:id/qr.png', (req, res) => {
    res.sendFile(sessionAssetPath(req.params.id, 'qr'), (err) => {
        if (err) res.status(404).json({ error: 'QR 이미지를 찾을 수 없습니다.' });
    });
});

/**
 * GET /api/sessions/:id/audio
 * 인준 목소리 mp3. 없으면 404 → 휴대폰은 기기 TTS로 넘어갑니다.
 */
app.get('/api/sessions/:id/audio', (req, res) => {
    if (!sessionHasAudio(req.params.id)) {
        return res.status(404).json({ error: '음성이 없습니다.' });
    }
    res.setHeader('Content-Type', 'audio/mpeg');
    res.sendFile(sessionAssetPath(req.params.id, 'audio'));
});

/**
 * GET /api/sessions/:id/workplan
 * QR이 들어간 작업계획서 다운로드
 */
app.get('/api/sessions/:id/workplan', async (req, res) => {
    try {
        const filePath = sessionAssetPath(req.params.id, 'workplan');
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'QR이 들어간 작업계획서를 찾을 수 없습니다.' });
        }
        const detail = await getSessionDetail(req.params.id);
        const rawTitle = detail?.workTitle || detail?.fileName || '작업계획서';
        const cleanTitle = String(rawTitle).trim().replace(/[\\/:*?"<>|]/g, '_');
        const filename = `${cleanTitle}_TBM.xlsx`;
        const encodedFilename = encodeURIComponent(filename).replace(/['()]/g, escape).replace(/\*/g, '%2A');

        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader(
            'Content-Disposition',
            `attachment; filename="workplan_TBM.xlsx"; filename*=UTF-8''${encodedFilename}`
        );
        res.sendFile(filePath);
    } catch (err) {
        console.error('[/api/sessions/:id/workplan] 다운로드 오류:', err);
        res.status(500).json({ error: '파일 다운로드 중 오류가 발생했습니다.' });
    }
});
app.get('/api/sessions/:id', async (req, res) => {
    try {
        await syncSessionFromPublic(req.params.id);
        const detail = await getSessionDetail(req.params.id, { includeImages: true });
        if (!detail) {
            return res.status(404).json({ error: '해당 TBM을 찾을 수 없습니다.' });
        }
        res.json(detail);
    } catch (err) {
        console.error('[/api/sessions/:id] 조회 오류:', err);
        res.status(500).json({ error: 'TBM 상세를 불러오지 못했습니다.' });
    }
});

/**
 * POST /api/sessions/:id/confirm
 * 작업자 서명을 취합해 로컬 이력으로 확정 저장
 */
app.post('/api/sessions/:id/confirm', async (req, res) => {
    try {
        const record = await completeSession(req.params.id, req.body?.signatures);
        res.json({
            id: record.id,
            status: record.status,
            completedAt: record.completedAt,
            signerCount: record.signatures.length,
        });
    } catch (err) {
        const status = err.statusCode || 500;
        if (status >= 500) console.error('[/api/sessions/:id/confirm] 오류:', err);
        res.status(status).json({ error: err.message || '서명 저장 중 오류가 발생했습니다.' });
    }
});

app.post('/api/sessions/:id/cancel', async (req, res) => {
    try {
        const record = await revertSessionSubmission(req.params.id);
        if (isPublicHostConfigured()) {
            await cancelPublicSession(req.params.id);
        }
        res.json({
            id: record.id,
            status: record.status,
            cancelled: true,
            cancelledAt: record.cancelledAt,
        });
    } catch (err) {
        const status = err.statusCode || 500;
        if (status >= 500) console.error('[/api/sessions/:id/cancel] 오류:', err);
        res.status(status).json({ error: err.message || '제출 취소 중 오류가 발생했습니다.' });
    }
});

/**
 * DELETE /api/sessions/:id
 * TBM 세션과 저장소 폴더를 삭제
 */
app.delete('/api/sessions/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const record = await getSessionDetail(id);
        if (!record) {
            return res.status(404).json({ error: '해당 TBM을 찾을 수 없습니다.' });
        }
        await deleteSession(id);
        res.json({ success: true, id, message: 'TBM 이력이 안전하게 삭제되었습니다.' });
    } catch (err) {
        console.error('[/api/sessions/:id DELETE] 오류:', err);
        res.status(500).json({ error: 'TBM 삭제 중 오류가 발생했습니다.' });
    }
});

app.get('/m/:id', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'mobile.html'));
});

app.get(['/history', '/history/:id'], (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'history.html'));
});

app.get(['/workplan-maker', '/plan-maker'], (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'workplan-maker.html'));
});

// ── SPA 폴백 ──
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── 서버 시작 ──
checkEnvVars();
app.listen(PORT, '0.0.0.0', async () => {
    try {
        const updated = await refreshBriefingLinks((id) => briefingUrl(id));
        if (updated > 0) console.log(`[저장소] 기존 QR ${updated}건을 반장용 주소로 갱신했습니다.`);
    } catch (err) {
        console.warn('[저장소] 시작 준비 실패:', err.message);
    }
    console.log('');
    console.log('╔══════════════════════════════════════════╗');
    console.log('║   🔧 작업계획서&TBM Maker                ║');
    console.log('╠══════════════════════════════════════════╣');
    console.log(`║   PC 접속: http://localhost:${PORT}          ║`);
    console.log(`║   관리페이지: http://localhost:${PORT}/history`);
    console.log('║   저장: tbm-store (원본·대본·서명)         ║');
    console.log('║   반장: 작업계획서 우측 하단 QR 스캔        ║');
    console.log('╚══════════════════════════════════════════╝');
    console.log(`[저장소] ${STORE_ROOT}`);
    if (publicBaseUrl()) console.log(`[반장] ${publicBaseUrl()}/m/<세션ID>`);
    console.log('');
});
