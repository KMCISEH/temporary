@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
    echo Node.js가 없습니다. https://nodejs.org 에서 LTS를 설치한 뒤 다시 실행하세요.
    pause
    exit /b 1
)

if not exist "node_modules\" (
    echo 처음 실행이라 필요한 프로그램을 설치합니다...
    call npm install
    if errorlevel 1 (
        echo 설치에 실패했습니다.
        pause
        exit /b 1
    )
)

if not exist ".env" (
    echo .env 파일이 없습니다.
    echo .env.example을 복사해 .env로 만든 뒤 API 키를 넣어주세요.
    pause
    exit /b 1
)

netstat -ano | findstr ":3000" | findstr "LISTENING" >nul
if not errorlevel 1 (
    echo 이미 켜져 있습니다. http://localhost:3000
    start "" "http://localhost:3000"
    ping 127.0.0.1 -n 3 >nul
    exit /b 0
)

echo 스마트 TBM 서버를 켭니다.
echo 주소: http://localhost:3000
echo 끄려면 이 창에서 Ctrl+C 를 누르세요.
echo.
start "" "http://localhost:3000"
node server.js
pause
