const { getSession, saveSession, getAudio, saveAudio } = require('../../../lib/store');
const { applyCors, sendJson, checkSecret } = require('../../../lib/http');

function sessionId(req) {
    if (req.query && req.query.id) return String(req.query.id);
    const parts = String(req.url || '').split('?')[0].split('/').filter(Boolean);
    const idx = parts.lastIndexOf('audio');
    if (idx > 0) return parts[idx - 1];
    return parts[parts.length - 1] || '';
}

/**
 * 요청 본문을 버퍼로 읽습니다. JSON이면 audioBase64를 꺼냅니다.
 * @param {import('http').IncomingMessage} req
 * @returns {Promise<Buffer>}
 */
async function readAudioBuffer(req) {
    const type = String(req.headers['content-type'] || '');
    if (req.body && typeof req.body === 'object' && !Buffer.isBuffer(req.body)) {
        const raw = String(req.body.audioBase64 || '').trim();
        return raw ? Buffer.from(raw, 'base64') : Buffer.alloc(0);
    }
    if (Buffer.isBuffer(req.body) && req.body.length) {
        if (type.includes('application/json')) {
            const parsed = JSON.parse(req.body.toString('utf8'));
            return Buffer.from(String(parsed.audioBase64 || ''), 'base64');
        }
        return req.body;
    }
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    const buf = Buffer.concat(chunks);
    if (!buf.length) return buf;
    if (type.includes('application/json')) {
        const parsed = JSON.parse(buf.toString('utf8'));
        return Buffer.from(String(parsed.audioBase64 || ''), 'base64');
    }
    return buf;
}

module.exports = async function handler(req, res) {
    applyCors(res);
    if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
    }

    const id = sessionId(req);
    if (!id) {
        return sendJson(res, 400, { error: '세션 ID가 필요합니다.' });
    }

    try {
        if (req.method === 'GET') {
            const buffer = await getAudio(id);
            if (!buffer) {
                return sendJson(res, 404, { error: '음성이 없습니다.' });
            }
            res.statusCode = 200;
            res.setHeader('Content-Type', 'audio/mpeg');
            res.setHeader('Cache-Control', 'public, max-age=3600');
            res.end(buffer);
            return;
        }

        if (req.method !== 'POST') {
            return sendJson(res, 405, { error: '허용되지 않은 요청입니다.' });
        }
        if (!checkSecret(req)) {
            return sendJson(res, 401, { error: '배포 비밀키가 올바르지 않습니다.' });
        }

        const buffer = await readAudioBuffer(req);
        if (!buffer.length) {
            return sendJson(res, 400, { error: '음성 데이터가 필요합니다.' });
        }

        await saveAudio(id, buffer);
        const session = await getSession(id);
        if (session) {
            session.hasAudio = true;
            await saveSession(session);
        }
        sendJson(res, 200, { id, hasAudio: true, bytes: buffer.length });
    } catch (err) {
        sendJson(res, 500, { error: err.message || '음성 처리에 실패했습니다.' });
    }
};
