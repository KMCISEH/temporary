const { getSession, saveSession } = require('../../../lib/store');
const { applyCors, sendJson } = require('../../../lib/http');

function sessionId(req) {
    if (req.query && req.query.id) return String(req.query.id);
    const parts = String(req.url || '').split('?')[0].split('/').filter(Boolean);
    const idx = parts.lastIndexOf('cancel');
    if (idx > 0) return parts[idx - 1];
    return parts[parts.length - 1] || '';
}

module.exports = async function handler(req, res) {
    applyCors(res);
    if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
    }
    if (req.method !== 'POST') {
        return sendJson(res, 405, { error: '허용되지 않은 요청입니다.' });
    }

    const id = sessionId(req);
    const session = await getSession(id);
    if (!session) {
        return sendJson(res, 404, { error: '해당 TBM을 찾을 수 없습니다.' });
    }
    if (session.status !== '완료') {
        return sendJson(res, 400, { error: '제출된 TBM이 없습니다.' });
    }

    const cancelledAt = new Date().toISOString();
    session.signatures = [];
    session.status = '배포됨';
    session.completedAt = null;
    session.cancelledAt = cancelledAt;
    await saveSession(session);

    sendJson(res, 200, {
        id: session.id,
        status: session.status,
        cancelled: true,
        cancelledAt,
    });
};
