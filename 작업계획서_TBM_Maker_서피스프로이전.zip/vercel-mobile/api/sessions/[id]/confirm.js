const { getSession, saveSession } = require('../../../lib/store');
const { applyCors, sendJson } = require('../../../lib/http');

module.exports = async function handler(req, res) {
    applyCors(res);
    if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
    }
    if (req.method !== 'POST') {
        return sendJson(res, 405, { error: '허용되지 않은 요청입니다.' });
    }

    const session = await getSession(req.query.id);
    if (!session) {
        return sendJson(res, 404, { error: '해당 TBM을 찾을 수 없습니다.' });
    }
    const signatures = req.body?.signatures;
    if (!Array.isArray(signatures)) {
        return sendJson(res, 400, { error: '서명이 필요합니다.' });
    }
    if (session.status !== '완료' && signatures.length === 0) {
        return sendJson(res, 400, { error: '서명이 필요합니다.' });
    }

    const saved = [];
    for (const item of signatures) {
        const name = String(item.name || '').trim();
        if (!name || !item.imageDataUrl) {
            return sendJson(res, 400, { error: '이름과 서명이 모두 필요합니다.' });
        }
        saved.push({
            name,
            signedAt: item.signedAt || new Date().toISOString(),
            imageDataUrl: item.imageDataUrl,
        });
    }

    session.signatures = saved;
    session.status = '완료';
    session.completedAt = new Date().toISOString();
    session.cancelledAt = null;
    await saveSession(session);

    sendJson(res, 200, {
        id: session.id,
        status: session.status,
        completedAt: session.completedAt,
        signerCount: session.signatures.length,
    });
};

module.exports.config = {
    api: { bodyParser: { sizeLimit: '4mb' } },
};
