const { getSession } = require('../../lib/store');
const { applyCors, sendJson, publicSession } = require('../../lib/http');

module.exports = async function handler(req, res) {
    applyCors(res);
    if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
    }
    if (req.method !== 'GET') {
        return sendJson(res, 405, { error: '허용되지 않은 요청입니다.' });
    }

    const session = await getSession(req.query.id || String(req.url || '').split('/').filter(Boolean).pop());
    if (!session) {
        return sendJson(res, 404, { error: '해당 TBM을 찾을 수 없습니다.' });
    }
    sendJson(res, 200, publicSession(session));
};
