const { saveSession, isVolatile } = require('../lib/store');
const { applyCors, sendJson, checkSecret, publicSession } = require('../lib/http');

module.exports = async function handler(req, res) {
    applyCors(res);
    if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
    }
    if (req.method !== 'POST') {
        return sendJson(res, 405, { error: '허용되지 않은 요청입니다.' });
    }
    if (!checkSecret(req)) {
        return sendJson(res, 401, { error: '배포 비밀키가 올바르지 않습니다.' });
    }

    const body = req.body || {};
    if (!body.id || !body.script) {
        return sendJson(res, 400, { error: '세션 ID와 TBM 대본이 필요합니다.' });
    }

    const session = publicSession({
        ...body,
        status: '배포됨',
        createdAt: body.createdAt || new Date().toISOString(),
        signatures: [],
    });

    await saveSession(session);
    sendJson(res, 200, { id: session.id, status: session.status, volatile: isVolatile() });
};
